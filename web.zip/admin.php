<?php
session_start();

if (($_SESSION['szerep'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Ehhez az oldalhoz admin jogosultság szükséges.');
}

require_once 'db.php';
require_once 'verseny_adatok.php';

$csrfToken = $_SESSION['csrf_token'] ?? bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrfToken;
$error = '';
$success = '';
$selectedContent = $_SERVER['REQUEST_METHOD'] === 'POST' ? ($_POST['content_selection'] ?? '') : 'new_news';
$resultSelection = $_SERVER['REQUEST_METHOD'] === 'POST' ? ($_POST['result_selection'] ?? '') : 'new_result';
$selectionIsValid = is_string($selectedContent)
	&& ($selectedContent === 'new_news'
		|| $selectedContent === 'new_competition'
		|| preg_match('/^(news|competition):([1-9][0-9]*)$/D', $selectedContent));
$resultSelectionIsValid = is_string($resultSelection)
	&& ($resultSelection === 'new_result' || preg_match('/^result:([1-9][0-9]*)$/D', $resultSelection));
$selectedContentType = 'news';
$selectedContentId = null;
$selectedResultId = null;
if (!$selectionIsValid) {
	$selectedContent = 'new_news';
} elseif ($selectedContent === 'new_competition') {
	$selectedContentType = 'competition';
} elseif (preg_match('/^(news|competition):([1-9][0-9]*)$/D', $selectedContent, $selectionMatch)) {
	$selectedContentType = $selectionMatch[1];
	$selectedContentId = (int)$selectionMatch[2];
}
if (!$resultSelectionIsValid) {
	$resultSelection = 'new_result';
} elseif (preg_match('/^result:([1-9][0-9]*)$/D', $resultSelection, $resultSelectionMatch)) {
	$selectedResultId = (int)$resultSelectionMatch[1];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!hash_equals($csrfToken, $_POST['csrf_token'] ?? '')) {
		http_response_code(403);
		$error = 'A kérés érvénytelen. Frissítsd az oldalt, majd próbáld újra.';
	} elseif (($_POST['action'] ?? '') === 'save_result' && !$resultSelectionIsValid) {
		$error = 'Válassz érvényes eredményt.';
	} elseif (($_POST['action'] ?? '') === 'save_result') {
		$competitionId = filter_var($_POST['eredmeny_verseny_id'] ?? null, FILTER_VALIDATE_INT);
		$accountIdInput = trim($_POST['felhasznalo_id'] ?? '');
		$accountId = $accountIdInput === '' ? null : filter_var($accountIdInput, FILTER_VALIDATE_INT);
		$participantName = trim($_POST['resztvevo_nev'] ?? '');
		$place = filter_var($_POST['helyezes'] ?? null, FILTER_VALIDATE_INT);
		$scoreInput = trim($_POST['pontszam'] ?? '');
		$notes = trim($_POST['megjegyzes'] ?? '');

		if (!$competitionId || $competitionId < 1) {
			$error = 'Válassz egy érvényes versenyt.';
		} elseif ($accountIdInput !== '' && (!$accountId || $accountId < 1)) {
			$error = 'Érvénytelen fiókazonosító.';
		} elseif (!$place || $place < 1 || $place > 65535) {
			$error = 'Adj meg 1 és 65535 közötti helyezést.';
		} elseif ($accountId === null && ($participantName === '' || strlen($participantName) > 100)) {
			$error = 'Vendég résztvevőnél adj meg legfeljebb 100 karakteres nevet.';
		} elseif ($scoreInput !== '' && !preg_match('/^\d{1,6}(?:\.\d{1,2})?$/D', $scoreInput)) {
			$error = 'A pontszám legfeljebb 999999.99 lehet.';
		} else {
			$competitionStmt = $pdo->prepare('SELECT id FROM versenyek WHERE id = ?');
			$competitionStmt->execute([$competitionId]);
			$accountName = null;
			if (!$competitionStmt->fetchColumn()) {
				$error = 'A kiválasztott verseny nem található.';
			} elseif ($accountId !== null) {
				$accountStmt = $pdo->prepare('SELECT teljes_nev FROM felhasznalok WHERE id = ?');
				$accountStmt->execute([$accountId]);
				$accountName = $accountStmt->fetchColumn();
				if ($accountName === false) {
					$error = 'A kiválasztott fiók nem található.';
				} else {
					$participantName = $accountName;
				}
			}

			if ($error === '' && $selectedResultId !== null) {
				$resultExistsStmt = $pdo->prepare('SELECT id FROM verseny_eredmenyek WHERE id = ?');
				$resultExistsStmt->execute([$selectedResultId]);
				if (!$resultExistsStmt->fetchColumn()) {
					$error = 'A módosítani kívánt eredmény nem található.';
				}
			}

			if ($error === '' && $accountId !== null) {
				$duplicateStmt = $pdo->prepare(
					'SELECT id FROM verseny_eredmenyek
					 WHERE verseny_id = ? AND felhasznalo_id = ? AND id <> ?
					 LIMIT 1'
				);
				$duplicateStmt->execute([$competitionId, $accountId, $selectedResultId ?? 0]);
				if ($duplicateStmt->fetchColumn()) {
					$error = 'Ez a fiók már szerepel ezen a versenyen.';
				}
			}

			if ($error === '') {
				$score = $scoreInput === '' ? null : $scoreInput;
				$notesValue = $notes === '' ? null : $notes;
				if ($selectedResultId !== null) {
					$stmt = $pdo->prepare(
						'UPDATE verseny_eredmenyek
						 SET verseny_id = ?, felhasznalo_id = ?, resztvevo_nev = ?, helyezes = ?, pontszam = ?, megjegyzes = ?
						 WHERE id = ?'
					);
					$stmt->execute([$competitionId, $accountId, $participantName, $place, $score, $notesValue, $selectedResultId]);
					$success = 'A versenyeredményt módosítottuk.';
				} else {
					$stmt = $pdo->prepare(
						'INSERT INTO verseny_eredmenyek (verseny_id, felhasznalo_id, resztvevo_nev, helyezes, pontszam, megjegyzes)
						 VALUES (?, ?, ?, ?, ?, ?)'
					);
					$stmt->execute([$competitionId, $accountId, $participantName, $place, $score, $notesValue]);
					$success = 'A versenyeredményt rögzítettük.';
				}
			}
		}
	} elseif (!$selectionIsValid) {
		$error = 'Válaszd ki a hozzáadni vagy módosítani kívánt tartalmat.';
	} elseif (($_POST['action'] ?? '') === 'save_content' && $selectedContentType === 'news') {
		$title = trim($_POST['hir_cim'] ?? '');
		$category = trim($_POST['hir_kategoria'] ?? '');
		$content = trim($_POST['hir_tartalom'] ?? '');
		$newsDate = trim($_POST['hir_datum'] ?? '');

		if ($title === '' || strlen($title) > 180) {
			$error = 'Adj meg egy legfeljebb 180 karakteres címet.';
		} elseif ($category === '' || strlen($category) > 80) {
			$error = 'Adj meg egy legfeljebb 80 karakteres kategóriát.';
		} elseif ($content === '') {
			$error = 'A hír szövege nem lehet üres.';
		} else {
			$date = DateTime::createFromFormat('!Y-m-d', $newsDate);
			if (!$date || $date->format('Y-m-d') !== $newsDate) {
				$error = 'Adj meg érvényes dátumot.';
			} else {
				if ($selectedContentId !== null) {
					$stmt = $pdo->prepare('UPDATE hirek SET cim = ?, kategoria = ?, tartalom = ?, datum = ? WHERE id = ?');
					$stmt->execute([$title, $category, $content, $newsDate, $selectedContentId]);
					if ($stmt->rowCount() > 0) {
						$success = 'A hírt sikeresen módosítottuk.';
					} else {
						$existsStmt = $pdo->prepare('SELECT id FROM hirek WHERE id = ?');
						$existsStmt->execute([$selectedContentId]);
						if ($existsStmt->fetchColumn()) {
							$success = 'A hír adatai már így szerepeltek.';
						} else {
							$error = 'A hír nem található.';
						}
					}
				} else {
					$stmt = $pdo->prepare('INSERT INTO hirek (cim, kategoria, tartalom, datum) VALUES (?, ?, ?, ?)');
					$stmt->execute([$title, $category, $content, $newsDate]);
					$success = 'A hírt sikeresen rögzítettük.';
				}
			}
		}
	} elseif (
		($_POST['action'] ?? '') === 'save_content'
		&& $selectedContentType === 'competition'
	) {
		$isUpdate = $selectedContentId !== null;
		$competitionId = $selectedContentId;
		$lakeId = filter_var($_POST['lake_id'] ?? null, FILTER_VALIDATE_INT);
		$competitionName = trim($_POST['verseny_nev'] ?? '');
		$description = trim($_POST['verseny_leiras'] ?? '');
		$competitionDate = trim($_POST['verseny_idopont'] ?? '');

		if ($competitionName === '' || strlen($competitionName) > 255) {
			$error = 'Adj meg egy legfeljebb 255 karakteres versenynevet.';
		} elseif (!$lakeId || $lakeId < 1) {
			$error = 'Válassz egy érvényes tavat.';
		} else {
			$databaseDate = null;
			if ($competitionDate !== '') {
				$date = DateTime::createFromFormat('!Y-m-d\\TH:i', $competitionDate);
				if (!$date || $date->format('Y-m-d\\TH:i') !== $competitionDate) {
					$error = 'Adj meg érvényes versenyidőpontot.';
				} else {
					$databaseDate = $date->format('Y-m-d H:i:s');
				}
			}

			if ($error === '') {
				$lakeStmt = $pdo->prepare('SELECT id FROM fishing_spots WHERE id = ?');
				$lakeStmt->execute([$lakeId]);
				$lake = $lakeStmt->fetch();
				if (!$lake) {
					$error = 'A kiválasztott tó nem található.';
				} elseif ($isUpdate) {
					$stmt = $pdo->prepare('UPDATE versenyek SET helyszin_id = ?, nev = ?, leiras = ?, idopont = ? WHERE id = ?');
					$stmt->execute([$lakeId, $competitionName, $description !== '' ? $description : null, $databaseDate, $competitionId]);
					if ($stmt->rowCount() > 0) {
						$success = 'A verseny adatait frissítettük.';
					} else {
						$existsStmt = $pdo->prepare('SELECT id FROM versenyek WHERE id = ?');
						$existsStmt->execute([$competitionId]);
						if ($existsStmt->fetchColumn()) {
							$success = 'A verseny adatai már így szerepeltek.';
						} else {
							$error = 'A verseny nem található.';
						}
					}
				} else {
					$stmt = $pdo->prepare('INSERT INTO versenyek (helyszin_id, nev, leiras, idopont) VALUES (?, ?, ?, ?)');
					$stmt->execute([$lakeId, $competitionName, $description !== '' ? $description : null, $databaseDate]);
					$success = 'A versenyt hozzáadtuk.';
				}
			}
		}
	} else {
		$error = 'Válaszd ki a hozzáadni vagy módosítani kívánt tartalmat.';
	}
}

$versenyek = versenyekLekerdezese($pdo);
$tavak = $pdo->query('SELECT MIN(id) AS id, nev, szelesseg, hosszusag FROM fishing_spots GROUP BY nev, szelesseg, hosszusag ORDER BY nev')->fetchAll();
$hirek = $pdo->query('SELECT id, cim, kategoria, tartalom, datum FROM hirek ORDER BY datum DESC, id DESC')->fetchAll();
$felhasznalok = $pdo->query('SELECT id, teljes_nev, email FROM felhasznalok ORDER BY teljes_nev')->fetchAll();
$eredmenyek = $pdo->query(
	'SELECT e.id, e.verseny_id, e.felhasznalo_id, e.resztvevo_nev, e.helyezes, e.pontszam, e.megjegyzes,
	        v.nev AS verseny_nev, v.idopont AS verseny_idopont, f.nev AS helyszin_nev
	 FROM verseny_eredmenyek e
	 INNER JOIN versenyek v ON v.id = e.verseny_id
	 INNER JOIN fishing_spots f ON f.id = v.helyszin_id
	 ORDER BY e.helyezes IS NULL, e.helyezes, e.resztvevo_nev'
)->fetchAll();
$contentOptions = [];
foreach ($hirek as $hir) {
	$contentOptions[] = [
		'value' => 'news:' . (int)$hir['id'],
		'label' => 'Hír - ' . $hir['cim'] . ' (' . date('Y-m-d', strtotime($hir['datum'])) . ')',
		'type' => 'news',
		'title' => $hir['cim'],
		'category' => $hir['kategoria'],
		'content' => $hir['tartalom'],
		'date' => date('Y-m-d', strtotime($hir['datum'])),
	];
}
foreach ($versenyek as $verseny) {
	$selectedLakeId = null;
	foreach ($tavak as $to) {
		if (
			$to['nev'] === $verseny['nev']
			&& (float)$to['szelesseg'] === (float)$verseny['szelesseg']
			&& (float)$to['hosszusag'] === (float)$verseny['hosszusag']
		) {
			$selectedLakeId = (int)$to['id'];
			break;
		}
	}
	$contentOptions[] = [
		'value' => 'competition:' . (int)$verseny['id'],
		'label' => 'Verseny - ' . $verseny['verseny_nev'] . ' / ' . $verseny['nev'] . ' (' . ($verseny['verseny_idopont'] ? date('Y-m-d', strtotime($verseny['verseny_idopont'])) : 'időpont nélkül') . ')',
		'type' => 'competition',
		'lakeId' => $selectedLakeId,
		'name' => $verseny['verseny_nev'],
		'description' => $verseny['leiras'] ?? '',
		'date' => $verseny['verseny_idopont'] ? date('Y-m-d\\TH:i', strtotime($verseny['verseny_idopont'])) : '',
	];
}
$contentOptionsJson = json_encode($contentOptions, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
$resultOptions = [];
foreach ($eredmenyek as $eredmeny) {
	$resultOptions[] = [
		'value' => 'result:' . (int)$eredmeny['id'],
		'label' => $eredmeny['helyezes'] . '. hely - ' . $eredmeny['resztvevo_nev'] . ' / ' . $eredmeny['verseny_nev'],
		'competitionId' => (int)$eredmeny['verseny_id'],
		'accountId' => $eredmeny['felhasznalo_id'] === null ? '' : (int)$eredmeny['felhasznalo_id'],
		'name' => $eredmeny['resztvevo_nev'],
		'place' => (int)$eredmeny['helyezes'],
		'score' => $eredmeny['pontszam'] === null ? '' : (string)$eredmeny['pontszam'],
		'notes' => $eredmeny['megjegyzes'] ?? '',
	];
}
$resultOptionsJson = json_encode($resultOptions, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
include 'header.php';
?>

<main class="admin-oldal">
	<div class="admin-oldal-fejlec">
		<div>
			<h1>Adminisztráció</h1>
			<p>Versenyek és hírek kezelése</p>
		</div>
	</div>

	<?php if ($error !== ''): ?>
		<div class="ertesites ertesites-hiba" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
	<?php endif; ?>
	<?php if ($success !== ''): ?>
		<div class="ertesites ertesites-siker" role="status"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
	<?php endif; ?>

	<section class="admin-szekcio">
		<h2>Hírek és versenyek kezelése</h2>
		<p class="admin-szerkeszto-leiras">Válassz egy meglévő tartalmat a módosításhoz, vagy indíts új hír/verseny rögzítését.</p>
		<form method="post">
			<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
			<input type="hidden" name="action" value="save_content">
			<div class="admin-tabla-gorgeto">
				<table class="admin-tabla admin-szerkeszto-tabla">
					<tbody>
						<tr>
							<th><label for="content_selection">Hozzáadás / módosítás</label></th>
							<td>
								<select id="content_selection" name="content_selection">
									<option value="new_news" <?php echo $selectedContent === 'new_news' ? 'selected' : ''; ?>>+ Új hír</option>
									<option value="new_competition" <?php echo $selectedContent === 'new_competition' ? 'selected' : ''; ?>>+ Új verseny</option>
									<?php if ($hirek): ?>
										<optgroup label="Meglévő hírek">
											<?php foreach ($contentOptions as $option): ?>
												<?php if ($option['type'] === 'news'): ?>
													<option value="<?php echo htmlspecialchars($option['value'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo $selectedContent === $option['value'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($option['label'], ENT_QUOTES, 'UTF-8'); ?></option>
												<?php endif; ?>
											<?php endforeach; ?>
										</optgroup>
									<?php endif; ?>
									<?php if ($versenyek): ?>
										<optgroup label="Meglévő versenyek">
											<?php foreach ($contentOptions as $option): ?>
												<?php if ($option['type'] === 'competition'): ?>
													<option value="<?php echo htmlspecialchars($option['value'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo $selectedContent === $option['value'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($option['label'], ENT_QUOTES, 'UTF-8'); ?></option>
												<?php endif; ?>
											<?php endforeach; ?>
										</optgroup>
									<?php endif; ?>
								</select>
							</td>
						</tr>
						<tr data-content-fields="news" <?php echo $selectedContentType !== 'news' ? 'hidden' : ''; ?>>
							<th><label for="hir_cim">Hír címe</label></th>
							<td><input id="hir_cim" name="hir_cim" maxlength="180" required value="<?php echo htmlspecialchars($_POST['hir_cim'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr data-content-fields="news" <?php echo $selectedContentType !== 'news' ? 'hidden' : ''; ?>>
							<th><label for="hir_kategoria">Kategória</label></th>
							<td><input id="hir_kategoria" name="hir_kategoria" maxlength="80" placeholder="Például: VERSENYINFÓ" required value="<?php echo htmlspecialchars($_POST['hir_kategoria'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr data-content-fields="news" <?php echo $selectedContentType !== 'news' ? 'hidden' : ''; ?>>
							<th><label for="hir_tartalom">Hír szövege</label></th>
							<td><textarea id="hir_tartalom" name="hir_tartalom" rows="5" required><?php echo htmlspecialchars($_POST['hir_tartalom'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea></td>
						</tr>
						<tr data-content-fields="news" <?php echo $selectedContentType !== 'news' ? 'hidden' : ''; ?>>
							<th><label for="hir_datum">Megjelenési dátum</label></th>
							<td><input id="hir_datum" name="hir_datum" type="date" required value="<?php echo htmlspecialchars($_POST['hir_datum'] ?? date('Y-m-d'), ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr data-content-fields="competition" <?php echo $selectedContentType !== 'competition' ? 'hidden' : ''; ?>>
							<th><label for="lake_id">Tó / helyszín</label></th>
							<td>
								<select id="lake_id" name="lake_id" required>
									<option value="">Válassz tavat</option>
									<?php foreach ($tavak as $to): ?>
										<option value="<?php echo (int)$to['id']; ?>" <?php echo (string)($_POST['lake_id'] ?? '') === (string)$to['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($to['nev'], ENT_QUOTES, 'UTF-8'); ?></option>
									<?php endforeach; ?>
								</select>
								<?php if (!$tavak): ?>
									<p class="profil-ures">A verseny rögzítéséhez előbb legalább egy tó/helyszín szükséges.</p>
								<?php endif; ?>
							</td>
						</tr>
						<tr data-content-fields="competition" <?php echo $selectedContentType !== 'competition' ? 'hidden' : ''; ?>>
							<th><label for="verseny_nev">Verseny neve / leírása</label></th>
							<td><input id="verseny_nev" name="verseny_nev" maxlength="255" required value="<?php echo htmlspecialchars($_POST['verseny_nev'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr data-content-fields="competition" <?php echo $selectedContentType !== 'competition' ? 'hidden' : ''; ?>>
							<th><label for="verseny_leiras">Verseny leírása</label></th>
							<td><textarea id="verseny_leiras" name="verseny_leiras" rows="3"><?php echo htmlspecialchars($_POST['verseny_leiras'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea></td>
						</tr>
						<tr data-content-fields="competition" <?php echo $selectedContentType !== 'competition' ? 'hidden' : ''; ?>>
							<th><label for="verseny_idopont">Verseny időpontja</label></th>
							<td><input id="verseny_idopont" name="verseny_idopont" type="datetime-local" value="<?php echo htmlspecialchars($_POST['verseny_idopont'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
					</tbody>
				</table>
			</div>
			<button type="submit" id="contentSubmitButton" class="kuldes-gomb">Mentés</button>
		</form>
	</section>

	<section class="admin-szekcio">
		<h2>Versenyeredmények</h2>
		<p class="admin-szerkeszto-leiras">Rögzítsd a helyezéseket. Bejelentkezett felhasználóhoz is kapcsolhatsz eredményt, vagy megadhatsz vendég résztvevőt.</p>
		<form method="post">
			<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
			<input type="hidden" name="action" value="save_result">
			<div class="admin-tabla-gorgeto">
				<table class="admin-tabla admin-szerkeszto-tabla">
					<tbody>
						<tr>
							<th><label for="result_selection">Eredmény kiválasztása</label></th>
							<td>
								<select id="result_selection" name="result_selection">
									<option value="new_result" <?php echo $resultSelection === 'new_result' ? 'selected' : ''; ?>>+ Új eredmény</option>
									<?php if ($resultOptions): ?>
										<optgroup label="Meglévő eredmények">
											<?php foreach ($resultOptions as $option): ?>
												<option value="<?php echo htmlspecialchars($option['value'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo $resultSelection === $option['value'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($option['label'], ENT_QUOTES, 'UTF-8'); ?></option>
											<?php endforeach; ?>
										</optgroup>
									<?php endif; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th><label for="eredmeny_verseny_id">Verseny</label></th>
							<td>
								<select id="eredmeny_verseny_id" name="eredmeny_verseny_id" required>
									<option value="">Válassz versenyt</option>
									<?php foreach ($versenyek as $verseny): ?>
										<option value="<?php echo (int)$verseny['id']; ?>" <?php echo (string)($_POST['eredmeny_verseny_id'] ?? '') === (string)$verseny['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($verseny['verseny_nev'] . ' / ' . $verseny['nev'], ENT_QUOTES, 'UTF-8'); ?></option>
									<?php endforeach; ?>
								</select>
								<?php if (!$versenyek): ?>
									<p class="profil-ures">Eredményrögzítés előtt adj hozzá versenyt, vagy helyezd át a régi versenyeket.</p>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th><label for="felhasznalo_id">Résztvevő fiókja (nem kötelező)</label></th>
							<td>
								<select id="felhasznalo_id" name="felhasznalo_id">
									<option value="">Vendég / nincs fiók</option>
									<?php foreach ($felhasznalok as $felhasznalo): ?>
										<option value="<?php echo (int)$felhasznalo['id']; ?>" <?php echo (string)($_POST['felhasznalo_id'] ?? '') === (string)$felhasznalo['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($felhasznalo['teljes_nev'] . ' (' . $felhasznalo['email'] . ')', ENT_QUOTES, 'UTF-8'); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th><label for="resztvevo_nev">Résztvevő neve</label></th>
							<td><input id="resztvevo_nev" name="resztvevo_nev" maxlength="100" required value="<?php echo htmlspecialchars($_POST['resztvevo_nev'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr>
							<th><label for="helyezes">Helyezés</label></th>
							<td><input id="helyezes" name="helyezes" type="number" min="1" max="65535" step="1" required value="<?php echo htmlspecialchars($_POST['helyezes'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr>
							<th><label for="pontszam">Pontszám (nem kötelező)</label></th>
							<td><input id="pontszam" name="pontszam" type="number" min="0" max="999999.99" step="0.01" value="<?php echo htmlspecialchars($_POST['pontszam'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"></td>
						</tr>
						<tr>
							<th><label for="megjegyzes">Megjegyzés (nem kötelező)</label></th>
							<td><textarea id="megjegyzes" name="megjegyzes" rows="3"><?php echo htmlspecialchars($_POST['megjegyzes'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea></td>
						</tr>
					</tbody>
				</table>
			</div>
			<button type="submit" id="resultSubmitButton" class="kuldes-gomb">Eredmény rögzítése</button>
		</form>

		<?php if ($eredmenyek): ?>
			<div class="admin-tabla-gorgeto">
				<table class="admin-tabla">
					<thead><tr><th>Verseny</th><th>Résztvevő</th><th>Helyezés</th><th>Pontszám</th></tr></thead>
					<tbody>
						<?php foreach ($eredmenyek as $eredmeny): ?>
							<tr>
								<td><?php echo htmlspecialchars($eredmeny['verseny_nev'] . ' / ' . $eredmeny['helyszin_nev'], ENT_QUOTES, 'UTF-8'); ?></td>
								<td><?php echo htmlspecialchars($eredmeny['resztvevo_nev'], ENT_QUOTES, 'UTF-8'); ?></td>
								<td><?php echo (int)$eredmeny['helyezes']; ?>.</td>
								<td><?php echo $eredmeny['pontszam'] === null ? '—' : htmlspecialchars((string)$eredmeny['pontszam'], ENT_QUOTES, 'UTF-8'); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else: ?>
			<p class="profil-ures">Még nincs rögzített versenyeredmény.</p>
		<?php endif; ?>
	</section>
</main>

<script>
	(() => {
		const contentSelection = document.getElementById('content_selection');
		const submitButton = document.getElementById('contentSubmitButton');
		if (!contentSelection || !submitButton) return;
		const contentOptions = <?php echo $contentOptionsJson ?: '[]'; ?>;
		const contentByValue = new Map(contentOptions.map((item) => [item.value, item]));
		const defaultNewsDate = document.getElementById('hir_datum').value;

		const updateContentFields = (loadSelectedItem) => {
			const isCompetition = contentSelection.value === 'new_competition' || contentSelection.value.startsWith('competition:');
			const contentType = isCompetition ? 'competition' : 'news';
			document.querySelectorAll('[data-content-fields]').forEach((section) => {
				const active = section.dataset.contentFields === contentType;
				section.hidden = !active;
				section.querySelectorAll('input, select, textarea').forEach((field) => {
					field.disabled = !active;
				});
			});
			const isExisting = contentSelection.value.includes(':');
			submitButton.textContent = isCompetition
				? (isExisting ? 'Verseny módosítása' : 'Verseny hozzáadása')
				: (isExisting ? 'Hír módosítása' : 'Hír közzététele');

			if (loadSelectedItem) {
				const item = contentByValue.get(contentSelection.value);
				if (contentType === 'news') {
					document.getElementById('hir_cim').value = item ? item.title : '';
					document.getElementById('hir_kategoria').value = item ? item.category : '';
					document.getElementById('hir_tartalom').value = item ? item.content : '';
					document.getElementById('hir_datum').value = item ? item.date : defaultNewsDate;
				} else {
					document.getElementById('lake_id').value = item && item.lakeId ? String(item.lakeId) : '';
					document.getElementById('verseny_nev').value = item ? item.name : '';
					document.getElementById('verseny_leiras').value = item ? item.description : '';
					document.getElementById('verseny_idopont').value = item ? item.date : '';
				}
			}
		};

		contentSelection.addEventListener('change', () => updateContentFields(true));
		updateContentFields(false);
	})();

	(() => {
		const resultSelection = document.getElementById('result_selection');
		const resultSubmitButton = document.getElementById('resultSubmitButton');
		if (!resultSelection || !resultSubmitButton) return;
		const resultOptions = <?php echo $resultOptionsJson ?: '[]'; ?>;
		const resultByValue = new Map(resultOptions.map((item) => [item.value, item]));
		const competitionSelect = document.getElementById('eredmeny_verseny_id');
		const accountSelect = document.getElementById('felhasznalo_id');
		const participantName = document.getElementById('resztvevo_nev');

		const updateResultFields = (loadSelectedItem) => {
			const item = resultByValue.get(resultSelection.value);
			if (loadSelectedItem) {
				competitionSelect.value = item ? String(item.competitionId) : '';
				accountSelect.value = item ? String(item.accountId) : '';
				participantName.value = item ? item.name : '';
				document.getElementById('helyezes').value = item ? String(item.place) : '';
				document.getElementById('pontszam').value = item ? item.score : '';
				document.getElementById('megjegyzes').value = item ? item.notes : '';
			}

			const accountSelected = accountSelect.value !== '';
			participantName.disabled = accountSelected;
			participantName.required = !accountSelected;
			resultSubmitButton.textContent = resultSelection.value.startsWith('result:')
				? 'Eredmény módosítása'
				: 'Eredmény rögzítése';
		};

		resultSelection.addEventListener('change', () => updateResultFields(true));
		accountSelect.addEventListener('change', () => updateResultFields(false));
		updateResultFields(false);
	})();
</script>

<?php include 'footer.php'; ?>
