<?php if (($_SESSION['szerep'] ?? '') === 'admin'): ?>
    <a class="admin-menu-gomb" href="admin.php">Admin</a>
<?php endif; ?>
