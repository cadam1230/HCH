<?php
session_start();

// Adatbázis kapcsolat bevonása
require_once 'db.php';

$error = '';
$success = '';


// Kijelentkezés kezelése
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header("Location: bejelentkezes.php");
    exit();
}

// 1. BEJELENTKEZÉS FELDOLGOZÁSA
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login_submit'])) {
    $email = trim($_POST['email']);
    $jelszo = $_POST['jelszo'];

    if (empty($email) || empty($jelszo)) {
        $error = "Minden mező kitöltése kötelező!";
    } else {
        $stmt = $pdo->prepare("SELECT id, teljes_nev, email, jelszo, szerep FROM felhasznalok WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($jelszo, $user['jelszo'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['teljes_nev'] = $user['teljes_nev'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['szerep'] = $user['szerep'];
            
            header("Location: index.php");
            exit();
        } else {
            $error = "Hibás felhasználónév/email vagy jelszó!";
        }
    }
}

// 2. REGISZTRÁCIÓ FELDOLGOZÁSA
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_submit'])) {
    $teljes_nev = trim($_POST['reg_teljes_nev']);
    $email = trim($_POST['reg_email']);
    $jelszo = $_POST['reg_jelszo'];
    $jelszo_ujra = $_POST['reg_jelszo_ujra'];

    if (empty($teljes_nev) || empty($email) || empty($jelszo)) {
        $error = "Minden mező kitöltése kötelező!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Adj meg érvényes e-mail címet!";
    } elseif ($jelszo !== $jelszo_ujra) {
        $error = "A két jelszó nem egyezik meg!";
    } elseif (strlen($jelszo) < 6) {
        $error = "A jelszónak legalább 6 karakteresnek kell lennie!";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM felhasznalok WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Ez a felhasználónév vagy e-mail cím már foglalt!";
        } else {
            $hashed_password = password_hash($jelszo, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO felhasznalok (teljes_nev, email, jelszo) VALUES (?, ?, ?)");
            
            if ($stmt->execute([$teljes_nev, $email, $hashed_password])) {
                $success = "Sikeres regisztráció! Most már bejelentkezhetsz.";
            } else {
                $error = "Hiba történt a regisztráció során!";
            }
        }
    }
}

// Bevonjuk a közös fejlécet
include 'header.php';
?>

<main>
    <div class="fiok-kartya">
        
        <?php if (isset($_SESSION['user_id'])): ?>
            <!-- Ha a felhasználó be van jelentkezve -->
            <h2>Üdvözlünk, <?php echo htmlspecialchars($_SESSION['teljes_nev']); ?>!</h2>
            <p style="margin: 20px 0; color: #a8bba9;">Be vagy jelentkezve ezzel az e-mail címmel: <strong><?php echo htmlspecialchars($_SESSION['email']); ?></strong></p>
            <a href="bejelentkezes.php?action=logout" class="kuldes-gomb" style="display:inline-block; text-decoration:none;">Kijelentkezés</a>
        
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <div class="fiok-fulek">
                <button class="fiok-ful <?php echo (isset($_POST['register_submit'])) ? '' : 'aktiv'; ?>" onclick="switchTab('login')">Bejelentkezés</button>
                <button class="fiok-ful <?php echo (isset($_POST['register_submit'])) ? 'aktiv' : ''; ?>" onclick="switchTab('register')">Regisztráció</button>
            </div>

            <?php if (!empty($error)): ?>
                <div class="ertesites ertesites-hiba"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="ertesites ertesites-siker"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- BEJELENTKEZÉSI ŰRLAP -->
            <form id="loginForm" class="fiok-urlap <?php echo (isset($_POST['register_submit'])) ? '' : 'aktiv'; ?>" action="bejelentkezes.php" method="POST">
                <div class="urlap-mezo">
                    <label for="email">E-mail cím</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="urlap-mezo">
                    <label for="jelszo">Jelszó</label>
                    <div class="jelszo-tarolo">
                        <input type="password" id="jelszo" name="jelszo" required>
                        <span class="jelszo-megjelenito" onclick="togglePasswordVisibility('jelszo', this)">👁️</span>
                    </div>
                </div>
                <button type="submit" name="login_submit" class="kuldes-gomb">Bejelentkezés</button>
            </form>

            <!-- REGISZTRÁCIÓS ŰRLAP -->
            <form id="registerForm" class="fiok-urlap <?php echo (isset($_POST['register_submit'])) ? 'aktiv' : ''; ?>" action="bejelentkezes.php" method="POST">
                <div class="urlap-mezo">
                    <label for="reg_teljes_nev">Teljes név</label>
                    <input type="text" id="reg_teljes_nev" name="reg_teljes_nev" required>
                </div>
                <div class="urlap-mezo">
                    <label for="reg_email">E-mail cím</label>
                    <input type="email" id="reg_email" name="reg_email" required>
                </div>
                <div class="urlap-mezo">
                    <label for="reg_jelszo">Jelszó</label>
                    <div class="jelszo-tarolo">
                        <input type="password" id="reg_jelszo" name="reg_jelszo" required>
                        <span class="jelszo-megjelenito" onclick="togglePasswordVisibility('reg_jelszo', this)">👁️</span>
                    </div>
                </div>
                <div class="urlap-mezo">
                    <label for="reg_jelszo_ujra">Jelszó újra</label>
                    <div class="jelszo-tarolo">
                        <input type="password" id="reg_jelszo_ujra" name="reg_jelszo_ujra" required>
                        <span class="jelszo-megjelenito" onclick="togglePasswordVisibility('reg_jelszo_ujra', this)">👁️</span>
                    </div>
                </div>
                <button type="submit" name="register_submit" class="kuldes-gomb">Regisztráció</button>
            </form>
        <?php endif; ?>

    </div>
</main>

<?php 
// Bevonjuk a közös láblécet
include 'footer.php'; 
?>