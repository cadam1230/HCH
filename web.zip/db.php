<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "horgaszto"; // Ügyelj rá, hogy a pontos adatbázisneved szerepeljen itt!

try {
    $conn = new mysqli($host, $user, $pass, $db);
    $conn->set_charset('utf8mb4');

    // PDO kapcsolat létrehozása UTF-8 kódolással
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (Throwable $e) {
    error_log($e->getMessage());
    http_response_code(500);
    die("Adatbázis csatlakozási hiba.");
}
?>