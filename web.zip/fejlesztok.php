<?php
require_once 'db.php';
require_once 'header.php';
?>

<main>
    <div class="page-title">
        <h1>Weboldal fejlesztése</h1>
        <p>A Horgász Challenge Hungary weboldal fejlesztéseinek és frissítéseinek naplója</p>
    </div>

    <div class="fejlesztes-lista">
        <div class="fejlesztes-elem">
            <span class="datum">2027.02.01</span>
            <h2>Versenyadatok automatikus frissítése</h2>
            <p>Az adatbázisban létrehozott vagy módosított versenyek megjelennek a versenyoldalon, a foglalásnál és a térképen.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2027.01.21</span>
            <h2>Versenyek adminisztrációja</h2>
            <p>Új versenyhelyszín rögzítése és a meglévő versenyidőpontok kezelése az adminfelületen.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2027.01.12</span>
            <h2>Adminisztrátori hozzáférés</h2>
            <p>Szerepkör-alapú admin jogosultság és védett adminisztrációs oldal.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2027.01.02</span>
            <h2>Közös versenyadatbázis</h2>
            <p>A versenylista, a foglalási helyszínek és a térképes jelölők közös adatforrásra kapcsolása.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.12.24</span>
            <h2>Foglalások módosítása és visszamondása</h2>
            <p>Saját foglalások szerkesztése, valamint a visszamondás megerősítő ablaka.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.12.14</span>
            <h2>Saját foglalások megjelenítése</h2>
            <p>A bejelentkezett felhasználó a profiloldalán áttekintheti a foglalásait és nevezéseit.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.12.05</span>
            <h2>Profilkép és jelszó kezelése</h2>
            <p>Profilkép feltöltése, valamint biztonságos jelszócsere a saját profiloldalon.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.11.25</span>
            <h2>Felhasználói profiloldal</h2>
            <p>Saját fiókadatok és a felhasználóhoz tartozó információk közös profilnézetben.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.11.16</span>
            <h2>AI-alapú galéria-visszajelzés</h2>
            <p>A nem odaillő képeknél felugró ablak helyett egyértelmű, újrapróbálható oldalon belüli üzenet jelenik meg.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.11.06</span>
            <h2>Biztonságos galériafeltöltés</h2>
            <p>Képfájl-ellenőrzés, duplikációszűrés és adatbázisba mentés a galériához.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.10.28</span>
            <h2>Adatbázis-kapcsolat és háttérrendszer</h2>
            <p>A foglalási és galériafunkciók szerveroldali adatkezelése.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.10.18</span>
            <h2>Dinamikus horgászhelyek</h2>
            <p>A horgászhelyek és versenyhelyszínek adatbázisból kerülnek a foglalóba.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.10.09</span>
            <h2>Foglalási naptár és dátumellenőrzés</h2>
            <p>A foglalt időpontok jelzése, a dátumkorlátok és az ütköző foglalások ellenőrzése.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.09.29</span>
            <h2>Online foglalási rendszer</h2>
            <p>Horgászhely- és versenyfoglalás adatbázisba mentéssel, szerkesztéssel és visszamondással.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.09.20</span>
            <h2>Mobilbarát megjelenés</h2>
            <p>A fejléc, a foglalási űrlap és a naptár igazítása mobil- és tabletméretekhez.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.09.10</span>
            <h2>Adatbázis és szerveroldali alapok</h2>
            <p>MySQL-kapcsolat és a weboldal fő adatkezelési folyamatainak kialakítása.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>

        <div class="fejlesztes-elem">
            <span class="datum">2026.09.01</span>
            <h2>Weboldal alapjai</h2>
            <p>A Horgász Challenge Hungary oldalstruktúrája és fő navigációja.</p>
            <span class="allapot kesz">Elkészült</span>
        </div>
    </div>

    <div class="technologiak">
        <h2>Mivel készült?</h2>
        <div class="technologia-lista">
            <span>HTML5</span>
            <span>CSS3</span>
            <span>JavaScript</span>
            <span>PHP</span>
            <span>MySQL</span>
            <span>REST API</span>
            <span>JSON</span>
        </div>
    </div>
</main>

<?php
require_once 'footer.php';
?>