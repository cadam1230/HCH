<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once 'db.php';
require_once 'verseny_adatok.php';
$versenyek = versenyekLekerdezese($pdo);
$versenyId = filter_var($_GET['verseny_id'] ?? null, FILTER_VALIDATE_INT);
$kivalasztottVerseny = null;
foreach ($versenyek as $verseny) {
    if ($versenyId && (int)$verseny['id'] === $versenyId) {
        $kivalasztottVerseny = $verseny;
        break;
    }
}
$versenyDatum = null;
if ($kivalasztottVerseny && !empty($kivalasztottVerseny['verseny_idopont'])) {
    $datum = strtotime($kivalasztottVerseny['verseny_idopont']);
    if ($datum !== false && date('Y-m-d', $datum) >= date('Y-m-d')) {
        $versenyDatum = date('Y-m-d', $datum);
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Online Horgászhely Foglalás</title>
    <link rel="stylesheet" href="stilusok.css?v=<?php echo filemtime(__DIR__ . '/stilusok.css'); ?>">
</head>
<body>

    <header>
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Horgász Challenge Hungary Logo" class="logo-kep">
            </a>
        </div>
        <?php include 'profil_menu.php'; ?>
        <div class="fejlec-gombok">
            <?php include 'admin_menu.php'; ?>
            <button class="menu-gomb" onclick="toggleMenu()">Menü ☰</button>
        </div>
    </header>

    <div class="menu-reteg" id="menuOverlay">
        <button class="close-btn" onclick="toggleMenu()">✕</button>
        <nav class="menu-tartalom">
            <ul>
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="foglalas.php">Foglalás</a></li>
                <li><a href="versenyek.php">Versenyek</a></li>
                <li><a href="galeria.php">Galéria</a></li>
                <li><a href="terkep.php">Térkép</a></li>
                <li><a href="hirek.php">Hírek</a></li>
                <li><a href="fejlesztok.php">Weboldal fejlesztői</a></li>
            </ul>
        </nav>
    </div>

    <main>
        <h1>Online Horgászverseny Foglalás</h1>
        <p>Válaszd ki a számodra megfelelő időpontot és stéget, majd küldd el a foglalásod.</p>

        <div class="foglalas-kontener">
            <form id="bookingForm" onsubmit="handleBooking(event)">
                <div class="urlap-mezo">
                    <label for="name">Név:</label>
                    <input type="text" id="name" required placeholder="Példa János" value="<?php echo htmlspecialchars($_SESSION['teljes_nev'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                </div>
                
                <div class="urlap-mezo">
                    <label for="email">E-mail cím:</label>
                    <input type="email" id="email" required placeholder="janos@pelda.hu" value="<?php echo htmlspecialchars($_SESSION['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" <?php echo isset($_SESSION['user_id']) ? 'readonly' : ''; ?>>
                </div>

                <input type="hidden" id="bookingId" value="">
                
                <div class="urlap-sor">
                    <div class="urlap-mezo">
                        <label for="dateFrom">Érkezés:</label>
                        <input type="date" id="dateFrom" min="<?php echo date('Y-m-d'); ?>" value="<?php echo htmlspecialchars($versenyDatum ?? '', ENT_QUOTES, 'UTF-8'); ?>" required onchange="validateSelectedDates()">
                    </div>
                    <div class="urlap-mezo">
                        <label for="dateTo">Távozás:</label>
                        <input type="date" id="dateTo" min="<?php echo date('Y-m-d'); ?>" value="<?php echo htmlspecialchars($versenyDatum ?? '', ENT_QUOTES, 'UTF-8'); ?>" required onchange="validateSelectedDates()">
                    </div>
                </div>
                
                <div class="urlap-mezo">
                    <label for="spot">Horgászhely / Verseny helyszín:</label>
                    <select id="spot" onchange="renderCalendars(); validateSelectedDates();">
                        <optgroup label="Állandó stégek (Edelény)">
                            <option value="1. stég (Mélyvíz) - Edelény">1. stég (Mélyvíz) - Edelény</option>
                            <option value="2. stég (Nádas) - Edelény">2. stég (Nádas) - Edelény</option>
                            <option value="3. stég (Sziget) - Edelény">3. stég (Sziget) - Edelény</option>
                        </optgroup>
                        <?php if ($versenyek): ?>
                            <optgroup label="Adatbázisban szereplő versenyhelyszínek">
                                <?php foreach ($versenyek as $verseny): ?>
                                    <option value="<?php echo htmlspecialchars($verseny['nev'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo $kivalasztottVerseny && (int)$verseny['id'] === (int)$kivalasztottVerseny['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($verseny['nev'], ENT_QUOTES, 'UTF-8'); ?>
                                        <?php if (!empty($verseny['leiras'])): ?>
                                            — <?php echo htmlspecialchars($verseny['leiras'], ENT_QUOTES, 'UTF-8'); ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </optgroup>
                        <?php endif; ?>
                    </select>
                </div>
                
                <button type="submit" id="bookingSubmitButton" class="kuldes-gomb">Foglalás elküldése</button>
                <button type="button" id="cancelBookingEdit" class="kuldes-gomb" hidden>Szerkesztés megszakítása</button>
                <div id="message"></div>
            </form>

            <?php if (isset($_SESSION['user_id'])): ?>
                <section class="sajat-foglalasok">
                    <h2>Saját foglalásaim</h2>
                    <div id="ownedBookings" aria-live="polite"></div>
                </section>
            <?php endif; ?>

            <div class="naptar-szekcio">
                <div class="naptar-cim">Foglaltsági Naptár</div>
                <div class="honapok-racs" id="monthsContainer"></div>
            </div>
        </div>
    </main>

    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="visszamondas-reteg" id="bookingCancelDialog" hidden aria-hidden="true">
            <section class="visszamondas-ablak" role="dialog" aria-modal="true" aria-labelledby="bookingCancelTitle" aria-describedby="bookingCancelDetails" tabindex="-1">
                <p class="visszamondas-jelzes">Foglaláskezelés</p>
                <h2 id="bookingCancelTitle">Visszamondod a foglalást?</h2>
                <p id="bookingCancelDetails" class="visszamondas-adatok"></p>
                <p class="visszamondas-figyelmeztetes">A visszamondás után az időpont újra foglalhatóvá válik.</p>
                <p id="bookingCancelError" class="visszamondas-hiba" role="alert" hidden></p>
                <div class="visszamondas-gombok">
                    <button type="button" id="cancelBookingDialogClose" class="visszamondas-megse">Mégse</button>
                    <button type="button" id="confirmBookingCancel" class="visszamondas-megerosit">Igen, visszamondom</button>
                </div>
            </section>
        </div>
    <?php endif; ?>

    <footer>
        <p>© 2026 Horgász Challenge Hungary - Minden jog fenntartva.</p>
    </footer>

    <script src="js.js"></script>
    <script>
        (() => {
            const arrivalInput = document.getElementById('dateFrom');
            const departureInput = document.getElementById('dateTo');
            const today = arrivalInput.min;

            const updateDepartureMinimum = () => {
                departureInput.min = arrivalInput.value || today;
                if (departureInput.value && departureInput.value < departureInput.min) {
                    departureInput.value = '';
                }
            };

            arrivalInput.addEventListener('input', updateDepartureMinimum);
            arrivalInput.addEventListener('change', updateDepartureMinimum);
            updateDepartureMinimum();
        })();
    </script>
</body>
</html>