    <div id="videoLightbox" class="video-nagyito-reteg">
        <span class="video-bezar" onclick="closeVideoLightbox()">&times;</span>

        <video id="lightboxVideo" controls autoplay>
            <source id="lightboxVideoSource" src="" type="video/mp4">
            A böngésződ nem támogatja a videó lejátszását.
        </video>
    </div>

    <footer>
        <p>© 2026 Horgász Challenge Hungary - Minden jog fenntartva.</p>
    </footer>

</body>
</html>