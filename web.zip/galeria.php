<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once 'db.php';

// Képek kiolvasása az adatbázisból (a legfrissebb kerül előre)
$sql = "SELECT kep_utvonal FROM galeria_kepek ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galéria - Edelényi Kavicsbányató</title>
    <link rel="stylesheet" href="stilusok.css?v=<?php echo filemtime(__DIR__ . '/stilusok.css'); ?>">
</head>

<body>

    <header>
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Logo" class="logo-kep">
            </a>
        </div>
        <?php include 'profil_menu.php'; ?>
        <div class="fejlec-gombok">
            <?php include 'admin_menu.php'; ?>
            <button class="menu-gomb" onclick="toggleMenu()">Menü ☰</button>
        </div>
    </header>

    <div class="menu-reteg" id="menuOverlay">
        <button class="close-btn" onclick="toggleMenu()">✕</button>
        <nav class="menu-tartalom">
            <ul>
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="foglalas.php">Foglalás</a></li>
                <li><a href="versenyek.php">Versenyek</a></li>
                <li><a href="galeria.php">Galéria</a></li>
                <li><a href="terkep.php">Térkép</a></li>
                <li><a href="hirek.php">Hírek</a></li>
                <li><a href="fejlesztok.php">Weboldal fejlesztői</a></li>
            </ul>
        </nav>
    </div>

    <main>
        <h1>Galéria</h1>
        <p>A horgásztónál készült legszebb pillanatok és fogások.</p>

        <div class="feltoltes-kartya">
            <h2 id="uploadTitle">AI modell betöltése folyamatban...</h2>
            <form id="uploadForm" class="feltoltes-urlap">
                <input type="file" id="imageInput" name="image" accept="image/*" disabled required>
                <button type="submit" id="uploadBtn" class="feltoltes-gomb" disabled>Kép hozzáadása</button>
            </form>
            <div id="uploadFeedback" class="feltoltes-visszajelzes" role="status" aria-live="polite" hidden>
                <span id="uploadFeedbackIcon" class="feltoltes-visszajelzes-ikon" aria-hidden="true"></span>
                <div class="feltoltes-visszajelzes-szoveg">
                    <strong id="uploadFeedbackTitle"></strong>
                    <p id="uploadFeedbackMessage"></p>
                </div>
                <button type="button" id="dismissUploadFeedback" class="feltoltes-visszajelzes-bezar" aria-label="Üzenet bezárása">×</button>
            </div>
        </div>

        <div class="galeria-racs" id="galleryGrid">
            <!-- ADATBÁZISBÓL SZÁRMAZÓ KÉPEK KÍRÁSA PHP-VAL -->
            <?php
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="galeria-elem"><img src="' . htmlspecialchars($row['kep_utvonal']) . '" alt="Fogás" loading="lazy"></div>';
                }
            }
            ?>
            
            <!-- ALAPÉRTELMEZETT / RÉGI KÉPEK -->
            <div class="galeria-elem"><img src="imgs/20260613_063524.jpg" alt="Fogás" loading="lazy"></div>
            <div class="galeria-elem"><img src="imgs/20260613_091100.jpg" alt="Fogás" loading="lazy"></div>
            <div class="galeria-elem"><img src="imgs/20260613_202656.jpg" alt="Fogás" loading="lazy"></div>
        </div>
    </main>

    <div class="kepnagyito-reteg" id="lightbox">
        <button class="kepnagyito-bezar" id="lightboxClose">✕</button>
        <button class="kepnagyito-gomb kepnagyito-elozo" id="lightboxPrev">&#10094;</button>
        <img class="kepnagyito-kep" id="lightboxImg" src="" alt="Nagyított kép">
        <button class="kepnagyito-gomb kepnagyito-kovetkezo" id="lightboxNext">&#10095;</button>
    </div>

    <footer>
        <p>© 2026 Horgász Challenge Hungary - Minden jog fenntartva.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet"></script>
    <script src="js.js"></script>
</body>

</html>