<?php if (session_status() !== PHP_SESSION_ACTIVE) session_start(); ?>
<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <title></title>
        <meta name="description" content="">

        <!-- Open Graph (Facebook, Messenger, stb.) -->
        <meta property="og:title" content="">
        <meta property="og:description" content="">
        <meta property="og:type" content="website">
        <meta property="og:url" content="">
        <meta property="og:image" content="">
        <link rel="icon" href="imgs/favicon.png" type="image/png">

        <!-- Google Fonts – csak amit tényleg használsz -->
        <link href="https://fonts.googleapis.com/css2?family=Impact&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Rubik&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Raleway&display=swap" rel="stylesheet">  
        <link href="https://fonts.googleapis.com/css2?family=Rubik&display=swap" rel="stylesheet">

        <!-- CSS -->
        <link rel="stylesheet" href="stilusok.css?v=<?php echo filemtime(__DIR__ . '/stilusok.css'); ?>" media="screen">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <link href="https://cdn.jsdelivr.net/npm/lightbox2@2/dist/css/lightbox.min.css" rel="stylesheet">

        <!-- JS könyvtárak -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/lightbox2@2/dist/js/lightbox.min.js"></script>

        <!-- Saját JS -->
        <script src="js.js"></script>  
    </head>
    <body>
        <header>
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Horgász Challenge Hungary! Logo" class="logo-kep">
            </a>
        </div>
        <?php include 'profil_menu.php'; ?>
        <div class="fejlec-gombok">
            <?php include 'admin_menu.php'; ?>
            <button class="menu-gomb" onclick="toggleMenu()">Menü ☰</button>
        </div>
    </header>

    <div class="menu-reteg" id="menuOverlay">
        <button class="close-btn" onclick="toggleMenu()">✕</button>
        <nav class="menu-tartalom">
            <ul>
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="foglalas.php">Foglalás</a></li>
                <li><a href="versenyek.php">Versenyek</a></li>
                <li><a href="galeria.php">Galéria</a></li>
                <li><a href="terkep.php">Térkép</a></li>
                <li><a href="hirek.php">Hírek</a></li>
                <li><a href="fejlesztok.php">Weboldal fejlesztői</a></li>
            </ul>
        </nav>
    </div>


<script>

</script>