<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once 'db.php';
$hirek = $pdo->query('SELECT cim, kategoria, tartalom, datum FROM hirek ORDER BY datum DESC, id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hírek - Edelényi Kavicsbányató</title>
    <link rel="stylesheet" href="stilusok.css?v=<?php echo filemtime(__DIR__ . '/stilusok.css'); ?>">
</head>

<body>

    <header>
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Horgász Challenge Hungary Logo" class="logo-kep">
            </a>
        </div>
        <?php include 'profil_menu.php'; ?>
        <div class="fejlec-gombok">
            <?php include 'admin_menu.php'; ?>
            <button class="menu-gomb" onclick="toggleMenu()">Menü ☰</button>
        </div>
    </header>

    <div class="menu-reteg" id="menuOverlay">
        <button class="close-btn" onclick="toggleMenu()">✕</button>
        <nav class="menu-tartalom">
            <ul>
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="foglalas.php">Foglalás</a></li>
                <li><a href="versenyek.php">Versenyek</a></li>
                <li><a href="galeria.php">Galéria</a></li>
                <li><a href="terkep.php">Térkép</a></li>
                <li><a href="hirek.php">Hírek</a></li>
                <li><a href="fejlesztok.php">Weboldal fejlesztői</a></li>
            </ul>
        </nav>
    </div>

    <main class="news-container">
        <h1>Friss Hírek és Események</h1>
        <p>Maradj naprakész a horgásztó legújabb fejleményeivel kapcsolatban.</p>

        <?php if ($hirek): ?>
            <?php foreach ($hirek as $hir): ?>
                <article class="hir-kartya">
                    <div class="hir-metaadat">
                        <span><?php echo htmlspecialchars($hir['kategoria'], ENT_QUOTES, 'UTF-8'); ?></span>
                        <time datetime="<?php echo htmlspecialchars($hir['datum'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(date('Y. m. d.', strtotime($hir['datum'])), ENT_QUOTES, 'UTF-8'); ?></time>
                    </div>
                    <h2><?php echo htmlspecialchars($hir['cim'], ENT_QUOTES, 'UTF-8'); ?></h2>
                    <p><?php echo nl2br(htmlspecialchars($hir['tartalom'], ENT_QUOTES, 'UTF-8')); ?></p>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Még nincs közzétett hír.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>© 2026 Horgász Challenge Hungary - Minden jog fenntartva.</p>
    </footer>

    <script src="js.js"></script>
</body>

</html>