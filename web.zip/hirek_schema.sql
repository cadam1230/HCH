CREATE TABLE IF NOT EXISTS hirek (
    id INT NOT NULL AUTO_INCREMENT,
    cim VARCHAR(180) NOT NULL,
    kategoria VARCHAR(80) NOT NULL DEFAULT 'EGYESÜLET',
    tartalom TEXT NOT NULL,
    datum DATE NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_hirek_datum (datum, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;
