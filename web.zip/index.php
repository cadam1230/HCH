<?php
require_once 'db.php';
$kiemeltHirek = $pdo->query('SELECT cim, kategoria, tartalom, datum FROM hirek ORDER BY datum DESC, id DESC LIMIT 2')->fetchAll();
include 'header.php';
?>

    <main>
        <section class="udvozlo-kartya">
            <h1>Üdvözlünk a Horgász Challenge Hungary Portálon!</h1>
            <p>Fedezd fel egyesületünk legfrissebb híreit, kövesd a folyamatosan frissülő versenynaptárt, és kukkants rá az interaktív térképünkre az aktuális helyszínekért!</p>
        </section>

        <section class="hirek-szekcio">
            <h2>Kiemelt híreink</h2>
            <div class="hirek-racs">
                <?php if ($kiemeltHirek): ?>
                    <?php foreach ($kiemeltHirek as $hir): ?>
                        <article class="hir-kartya">
                            <div class="hir-metaadat">
                                <span><?php echo htmlspecialchars($hir['kategoria'], ENT_QUOTES, 'UTF-8'); ?></span>
                                <time datetime="<?php echo htmlspecialchars($hir['datum'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(date('Y. m. d.', strtotime($hir['datum'])), ENT_QUOTES, 'UTF-8'); ?></time>
                            </div>
                            <h3><?php echo htmlspecialchars($hir['cim'], ENT_QUOTES, 'UTF-8'); ?></h3>
                            <p><?php echo nl2br(htmlspecialchars($hir['tartalom'], ENT_QUOTES, 'UTF-8')); ?></p>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Még nincs kiemelt hír.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

<?php include 'footer.php'; ?>