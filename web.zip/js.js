// Globális menükezelő függvény (a HTML-ben lévő onclick="toggleMenu()" ezt hívja meg)
function toggleMenu() {
    const overlay = document.getElementById('menuOverlay');
    if (overlay) {
        overlay.classList.toggle('aktiv');
    }
}

function switchTab(tab) {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const tabs = document.querySelectorAll('.fiok-ful');
    const showLogin = tab === 'login';

    if (!loginForm || !registerForm) return;
    loginForm.classList.toggle('aktiv', showLogin);
    registerForm.classList.toggle('aktiv', !showLogin);
    tabs.forEach((button, index) => button.classList.toggle('aktiv', index === (showLogin ? 0 : 1)));
}

function togglePasswordVisibility(inputId, toggle) {
    const input = document.getElementById(inputId);
    if (!input) return;

    input.type = input.type === 'password' ? 'text' : 'password';
    toggle.setAttribute('aria-label', input.type === 'password' ? 'Jelszó megjelenítése' : 'Jelszó elrejtése');
}

// Billentyűzet és menüpont kattintás események kezelése
document.addEventListener('DOMContentLoaded', () => {
    
    // Menü bezárása az ESC billentyű megnyomásával
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            const overlay = document.getElementById('menuOverlay');
            if (overlay && overlay.classList.contains('aktiv')) {
                overlay.classList.remove('aktiv');
            }
        }
    });

    // Menü bezárása, ha rákoppintanak/kattintanak egy menüpontra
    document.querySelectorAll('.menu-tartalom a').forEach(link => {
        link.addEventListener('click', () => {
            const overlay = document.getElementById('menuOverlay');
            if (overlay) {
                overlay.classList.remove('aktiv');
            }
        });
    });

    // Foglalási űrlap kezelése (ha a foglalás oldalon vagyunk)
    const form = document.getElementById('foglalasForm');
    const statusMsg = document.getElementById('statusMsg');

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const nev = document.getElementById('nev').value;
            const email = document.getElementById('email').value;
            const erkezes = document.getElementById('erkezes').value;
            const tavozas = document.getElementById('tavozas').value;
            const hely = document.getElementById('hely').value;

            statusMsg.style.color = '#ffc107';
            statusMsg.textContent = 'Foglalás küldése...';

            try {
                const response = await fetch('/api/foglalas', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ nev, email, erkezes, tavozas, hely })
                });

                const data = await response.json();

                if (response.ok) {
                    statusMsg.style.color = '#4caf50';
                    statusMsg.textContent = data.message;
                    form.reset();
                } else {
                    statusMsg.style.color = '#f44336';
                    statusMsg.textContent = data.message || 'Hiba történt a foglalás során!';
                }
            } catch (error) {
                console.error('Hiba:', error);
                statusMsg.style.color = '#f44336';
                statusMsg.textContent = 'Nem sikerült kapcsolódni a szerverhez!';
            }
        });
    }
});
// Globális tömb a lefoglalt dátumok tárolására
let bookedDates = [];

// Menü megnyitása / bezárása
function toggleMenu() {
    const overlay = document.getElementById('menuOverlay');
    overlay.classList.toggle('aktiv');
}

// Foglalások lekérése a szerverről
function fetchReservations() {
    const spot = document.getElementById('spot').value;
    document.getElementById('calendarTitle').innerText = `${spot} - Foglaltság`;

    fetch(`save_booking.php?spot=${encodeURIComponent(spot)}`)
        .then(response => response.json())
        .then(data => {
            bookedDates = data;
            renderCalendars();
        })
        .catch(err => {
            console.error('Hiba a foglalások lekérésekor:', err);
            bookedDates = [];
            renderCalendars();
        });
}

// Dátumok ellenőrzése kiválasztáskor
function validateSelectedDates() {
    const checkin = document.getElementById('checkin').value;
    const checkout = document.getElementById('checkout').value;

    if (!checkin) return;

    if (bookedDates.includes(checkin)) {
        alert('A kiválasztott érkezési nap már foglalt!');
        document.getElementById('checkin').value = '';
        return;
    }

    if (checkout) {
        if (checkout < checkin) {
            alert('A távozás dátuma nem lehet korábbi, mint az érkezésé!');
            document.getElementById('checkout').value = '';
            return;
        }

        // Intervallum ellenőrzése
        let curr = new Date(checkin);
        const end = new Date(checkout);
        let hasOverlap = false;

        while (curr <= end) {
            const dateStr = curr.toISOString().split('T')[0];
            if (bookedDates.includes(dateStr)) {
                hasOverlap = true;
                break;
            }
            curr.setDate(curr.getDate() + 1);
        }

        if (hasOverlap) {
            alert('A kiválasztott időszakban van már foglalt nap! Kérjük válasszon másik intervallumot.');
            document.getElementById('checkout').value = '';
        }
    }
}

// Naptár kirajzolása
function renderCalendars() {
    const container = document.getElementById('calendarContainer');
    container.innerHTML = '';

    // Megjelenítendő hónapok (2026 Július - Október)
    const months = [
        { name: '2026 Július', year: 2026, month: 6, days: 31, startDay: 2 }, 
        { name: '2026 Augusztus', year: 2026, month: 7, days: 31, startDay: 5 }, 
        { name: '2026 Szeptember', year: 2026, month: 8, days: 30, startDay: 1 }, 
        { name: '2026 Október', year: 2026, month: 9, days: 31, startDay: 3 } 
    ];

    months.forEach(m => {
        const monthCard = document.createElement('div');
        monthCard.className = 'honap-kartya';

        let html = `
            <div class="honap-cim">${m.name}</div>
            <div class="napok-fejlec">
                <div>H</div><div>K</div><div>Sze</div><div>Cs</div><div>P</div><div>Szo</div><div>V</div>
            </div>
            <div class="napok-racs">
        `;

        // Üres cellák a hónap kezdete előtt
        for (let i = 0; i < m.startDay; i++) {
            html += `<div class="nap nap-ures"></div>`;
        }

        // Napok kirajzolása
        for (let day = 1; day <= m.days; day++) {
            const monthStr = String(m.month + 1).padStart(2, '0');
            const dayStr = String(day).padStart(2, '0');
            const fullDate = `${m.year}-${monthStr}-${dayStr}`;

            const isBooked = bookedDates.includes(fullDate);
            const statusClass = isBooked ? 'nap-foglalt' : 'nap-szabad';

            html += `<div class="nap ${statusClass}">${day}</div>`;
        }

        html += `</div>`;
        monthCard.innerHTML = html;
        container.appendChild(monthCard);
    });
}

// Űrlap elküldése
function handleBooking(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const spot = document.getElementById('spot').value;
    const checkin = document.getElementById('checkin').value;
    const checkout = document.getElementById('checkout').value;

    const data = { name, email, spot, checkin, checkout };

    fetch('save_booking.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            alert('Sikeres foglalás!');
            document.getElementById('bookingForm').reset();
            fetchReservations();
        } else {
            alert('Hiba történt: ' + (result.message || 'Sikertelen foglalás'));
        }
    })
    .catch(err => {
        console.error('Hiba:', err);
        alert('Hálózati hiba történt a foglalás során.');
    });
}

// Inicializálás az oldal betöltésekor
document.addEventListener('DOMContentLoaded', () => {
    fetchReservations();
});

let serverReservations = [];

window.onload = async function() {
    const dateFromInput = document.getElementById('dateFrom');
    const dateToInput = document.getElementById('dateTo');
    if (!dateFromInput || !dateToInput) return;

    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    dateFromInput.min = today;
    dateToInput.min = today;

    const urlParams = new URLSearchParams(window.location.search);
    const helyszin = urlParams.get('hely');
    if (helyszin) {
        document.getElementById('spot').value = helyszin;
    }
    await fetchReservations();
    await loadOwnBookings();
};

function toggleMenu() {
    const overlay = document.getElementById('menuOverlay');
    overlay.classList.toggle('aktiv');
}

// LEKÉRÉS PHP-BÓL
async function fetchReservations() {
    try {
        const res = await fetch('save_booking.php');
        if (res.ok) {
            serverReservations = await res.json();
            renderCalendars();
        }
    } catch (err) {
        console.error("Hiba a naptár adatok betöltésekor:", err);
    }
}

function validateSelectedDates() {
    const dateFromInput = document.getElementById('dateFrom');
    const dateToInput = document.getElementById('dateTo');
    const selectedSpot = document.getElementById('spot').value;
    const messageDiv = document.getElementById('message');

    const dateFrom = dateFromInput.value;
    const dateTo = dateToInput.value;
    const currentBookingId = Number(document.getElementById('bookingId')?.value) || null;

    dateToInput.min = dateFrom || dateFromInput.min;
    messageDiv.textContent = ''; 

    if (dateFrom && dateTo && dateTo < dateFrom) {
        messageDiv.style.color = '#ff3333';
        messageDiv.textContent = 'A távozás napja nem lehet korábbi az érkezésnél!';
        dateToInput.value = '';
        return;
    }

    if (dateFrom && checkDayBooking(selectedSpot, dateFrom, currentBookingId)) {
        alert("Sajnos a kiválasztott ÉRKEZÉSI nap már foglalt! Kérjük, válassz másik zöld színű napot.");
        dateFromInput.value = '';
        return;
    }

    if (dateTo && checkDayBooking(selectedSpot, dateTo, currentBookingId)) {
        alert("Sajnos a kiválasztott TÁVOZÁSI nap már foglalt! Kérjük, válassz másik zöld színű napot.");
        dateToInput.value = '';
        return;
    }

    if (dateFrom && dateTo) {
        let start = new Date(dateFrom);
        let end = new Date(dateTo);
        let current = new Date(start);

        while (current <= end) {
            let y = current.getFullYear();
            let m = String(current.getMonth() + 1).padStart(2, '0');
            let d = String(current.getDate()).padStart(2, '0');
            let formattedCurrentDate = `${y}-${m}-${d}`;

            if (checkDayBooking(selectedSpot, formattedCurrentDate, currentBookingId)) {
                alert("A kiválasztott időintervallum foglalt napot tartalmaz! Kérjük, válassz másik időszakot.");
                dateFromInput.value = '';
                dateToInput.value = '';
                break;
            }
            current.setDate(current.getDate() + 1);
        }
    }
}

function renderCalendars() {
    const container = document.getElementById('monthsContainer');
    if (!container) return;
    container.innerHTML = '';
    
    const selectedSpot = document.getElementById('spot').value;
    const year = 2026;
    
    const monthsToRender = [
        { name: 'Július', monthIdx: 6 },
        { name: 'Augusztus', monthIdx: 7 },
        { name: 'Szeptember', monthIdx: 8 },
        { name: 'Október', monthIdx: 9 }
    ];

    monthsToRender.forEach(m => {
        let monthBox = document.createElement('div');
        monthBox.className = 'honap-doboz';
        
        let mName = document.createElement('div');
        mName.className = 'honap-nev';
        mName.innerText = `${year}. ${m.name}`;
        monthBox.appendChild(mName);
        
        let daysGrid = document.createElement('div');
        daysGrid.className = 'napok-racs';
        
        const dayLabels = ['H', 'K', 'Sze', 'Cs', 'P', 'Szo', 'V'];
        dayLabels.forEach(l => {
            let lbl = document.createElement('div');
            lbl.className = 'nap-felirat';
            lbl.innerText = l;
            daysGrid.appendChild(lbl);
        });
        
        let firstDay = new Date(year, m.monthIdx, 1);
        let startDayOfWeek = firstDay.getDay(); 
        let shifts = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1;
        
        for(let e = 0; e < shifts; e++) {
            let emptyCell = document.createElement('div');
            emptyCell.className = 'nap-ures';
            daysGrid.appendChild(emptyCell);
        }
        
        let totalDays = new Date(year, m.monthIdx + 1, 0).getDate();
        
        for(let d = 1; d <= totalDays; d++) {
            let dayCell = document.createElement('div');
            dayCell.className = 'nap-cella';
            dayCell.innerText = d;
            
            let currentMonthString = String(m.monthIdx + 1).padStart(2, '0');
            let currentDayString = String(d).padStart(2, '0');
            let dateStr = `${year}-${currentMonthString}-${currentDayString}`;
            
            let isBooked = checkDayBooking(selectedSpot, dateStr);
            
            if(isBooked) {
                dayCell.classList.add('nap-foglalt');
            } else {
                dayCell.classList.add('nap-szabad');
            }
            
            daysGrid.appendChild(dayCell);
        }
        
        monthBox.appendChild(daysGrid);
        container.appendChild(monthBox);
    });
}

function checkDayBooking(spot, dateStr, excludeId = null) {
    for(let res of serverReservations) {
        if (excludeId && Number(res.id) === excludeId) continue;
        if(res.steg === spot) {
            let startDate = res.datum_kezdet;
            let endDate = res.datum_veg;
            
            if(dateStr >= startDate && dateStr <= endDate) {
                return true;
            }
        }
    }
    return false;
}

// KÜLDÉS PHP BACKENDRE
async function handleBooking(e) {
    if(e) e.preventDefault();
    
    const nev = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const datum_kezdet = document.getElementById('dateFrom').value;
    const datum_veg = document.getElementById('dateTo').value;
    const steg = document.getElementById('spot').value;
    const messageDiv = document.getElementById('message');
    const bookingId = document.getElementById('bookingId').value;
    const submitButton = document.getElementById('bookingSubmitButton');

    if(!nev || !email || !datum_kezdet || !datum_veg || !steg) return;

    try {
        const payload = { nev, email, datum_kezdet, datum_veg, steg };
        if (bookingId) payload.id = Number(bookingId);

        const response = await fetch('save_booking.php', {
            method: bookingId ? 'PUT' : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const resData = await response.json();

        if (response.ok) {
            messageDiv.style.color = '#4caf50';
            messageDiv.textContent = resData.message;
            document.getElementById('bookingForm').reset();
            document.getElementById('bookingId').value = '';
            document.getElementById('spot').value = steg;
            submitButton.textContent = 'Foglalás elküldése';
            document.getElementById('cancelBookingEdit').hidden = true;
            await fetchReservations();
            await loadOwnBookings();
        } else {
            messageDiv.style.color = '#ff3333';
            messageDiv.textContent = resData.message || 'Hiba történt.';
        }
    } catch (err) {
        messageDiv.style.color = '#ff3333';
        messageDiv.textContent = 'Szerverhiba! Ellenőrizd a szervert!';
    }
}

async function loadOwnBookings() {
    const container = document.getElementById('ownedBookings');
    if (!container) return;

    try {
        const response = await fetch('save_booking.php?mine=1');
        const bookings = await response.json();
        if (!response.ok) throw new Error(bookings.message || 'A foglalások betöltése nem sikerült.');

        container.replaceChildren();
        if (bookings.length === 0) {
            container.textContent = 'Még nincs rögzített foglalásod.';
            return;
        }

        bookings.forEach((booking) => {
            const row = document.createElement('div');
            row.className = 'sajat-foglalas-elem';

            const details = document.createElement('div');
            details.className = 'sajat-foglalas-adatok';
            const location = document.createElement('strong');
            location.textContent = booking.steg;
            const dates = document.createElement('span');
            dates.textContent = `${booking.datum_kezdet} - ${booking.datum_veg}`;
            details.append(location, dates);

            const editButton = document.createElement('button');
            editButton.type = 'button';
            editButton.className = 'sajat-foglalas-szerkesztes';
            editButton.textContent = 'Szerkesztés';
            editButton.addEventListener('click', () => beginBookingEdit(booking));

            const actions = document.createElement('div');
            actions.className = 'sajat-foglalas-gombok';
            actions.appendChild(editButton);

            const deleteButton = document.createElement('button');
            deleteButton.type = 'button';
            deleteButton.className = 'sajat-foglalas-torles';
            deleteButton.textContent = 'Visszamondás';
            deleteButton.addEventListener('click', () => cancelBooking(booking));
            actions.appendChild(deleteButton);

            row.append(details, actions);
            container.appendChild(row);
        });
    } catch (error) {
        container.textContent = error.message;
    }
}

let pendingBookingCancellation = null;
let cancellationDialogOpener = null;
let cancellationDialogCloseTimer = null;

function cancelBooking(booking) {
    const dialog = document.getElementById('bookingCancelDialog');
    if (!dialog) return;

    pendingBookingCancellation = booking;
    cancellationDialogOpener = document.activeElement;
    document.getElementById('bookingCancelDetails').textContent = `${booking.steg} · ${booking.datum_kezdet} - ${booking.datum_veg}`;
    document.getElementById('bookingCancelError').hidden = true;
    document.getElementById('bookingCancelError').textContent = '';
    window.clearTimeout(cancellationDialogCloseTimer);
    dialog.hidden = false;
    dialog.setAttribute('aria-hidden', 'false');
    requestAnimationFrame(() => {
        dialog.classList.add('aktiv');
        document.getElementById('cancelBookingDialogClose').focus();
    });
}

function closeBookingCancelDialog() {
    const dialog = document.getElementById('bookingCancelDialog');
    if (!dialog || dialog.hidden) return;

    dialog.classList.remove('aktiv');
    dialog.setAttribute('aria-hidden', 'true');
    cancellationDialogCloseTimer = window.setTimeout(() => {
        dialog.hidden = true;
    }, 180);
    pendingBookingCancellation = null;
    if (cancellationDialogOpener?.isConnected) cancellationDialogOpener.focus();
}

async function confirmBookingCancellation() {
    if (!pendingBookingCancellation) return;

    const confirmButton = document.getElementById('confirmBookingCancel');
    const errorMessage = document.getElementById('bookingCancelError');
    confirmButton.disabled = true;
    confirmButton.textContent = 'Visszamondás...';
    errorMessage.hidden = true;

    const messageDiv = document.getElementById('message');
    try {
        const response = await fetch('save_booking.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: Number(pendingBookingCancellation.id) })
        });
        const result = await response.json();

        if (!response.ok) {
            errorMessage.textContent = result.message || 'A foglalást nem sikerült visszamondani.';
            errorMessage.hidden = false;
            return;
        }

        const cancelledId = Number(pendingBookingCancellation.id);
        closeBookingCancelDialog();
        messageDiv.style.color = '#4caf50';
        messageDiv.textContent = result.message;

        if (Number(document.getElementById('bookingId').value) === cancelledId) {
            document.getElementById('bookingForm').reset();
            document.getElementById('bookingId').value = '';
            document.getElementById('bookingSubmitButton').textContent = 'Foglalás elküldése';
            document.getElementById('cancelBookingEdit').hidden = true;
            document.getElementById('dateTo').min = document.getElementById('dateFrom').min;
        }

        await fetchReservations();
        await loadOwnBookings();
    } catch (error) {
        errorMessage.textContent = 'Szerverhiba! A foglalást nem sikerült visszamondani.';
        errorMessage.hidden = false;
    } finally {
        confirmButton.disabled = false;
        confirmButton.textContent = 'Igen, visszamondom';
    }
}

function beginBookingEdit(booking) {
    document.getElementById('bookingId').value = booking.id;
    document.getElementById('name').value = booking.nev;
    document.getElementById('email').value = booking.email;
    document.getElementById('dateFrom').value = booking.datum_kezdet;
    document.getElementById('dateTo').value = booking.datum_veg;
    document.getElementById('spot').value = booking.steg;
    document.getElementById('dateTo').min = booking.datum_kezdet;
    document.getElementById('bookingSubmitButton').textContent = 'Módosítás mentése';
    document.getElementById('cancelBookingEdit').hidden = false;
    document.getElementById('message').textContent = '';
    renderCalendars();
    document.getElementById('bookingForm').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

document.addEventListener('DOMContentLoaded', () => {
    const cancelButton = document.getElementById('cancelBookingEdit');
    if (cancelButton) {
        cancelButton.addEventListener('click', () => {
            document.getElementById('bookingForm').reset();
            document.getElementById('bookingId').value = '';
            document.getElementById('bookingSubmitButton').textContent = 'Foglalás elküldése';
            cancelButton.hidden = true;
            document.getElementById('dateTo').min = document.getElementById('dateFrom').min;
            document.getElementById('message').textContent = '';
            renderCalendars();
        });
    }

    const confirmationDialog = document.getElementById('bookingCancelDialog');
    if (!confirmationDialog) return;

    document.getElementById('cancelBookingDialogClose').addEventListener('click', closeBookingCancelDialog);
    document.getElementById('confirmBookingCancel').addEventListener('click', confirmBookingCancellation);
    confirmationDialog.addEventListener('click', (event) => {
        if (event.target === confirmationDialog) closeBookingCancelDialog();
    });
    document.addEventListener('keydown', (event) => {
        if (confirmationDialog.hidden) return;
        if (event.key === 'Escape') {
            closeBookingCancelDialog();
            return;
        }
        if (event.key === 'Tab') {
            const focusable = confirmationDialog.querySelectorAll('button:not([disabled])');
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        }
    });
});

let aiModel = null;
let updateGalleryImages = () => {};

function toggleMenu() {
    const overlay = document.getElementById('menuOverlay');
    if (overlay) overlay.classList.toggle('aktiv');
}

document.addEventListener('DOMContentLoaded', async () => {
    const uploadTitle = document.getElementById('uploadTitle');
    const uploadBtn = document.getElementById('uploadBtn');
    const imageInput = document.getElementById('imageInput');
    const uploadForm = document.getElementById('uploadForm');
    const galleryGrid = document.getElementById('galleryGrid');
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightboxImg');
    const closeBtn = document.getElementById('lightboxClose');
    const prevBtn = document.getElementById('lightboxPrev');
    const nextBtn = document.getElementById('lightboxNext');
    const uploadFeedback = document.getElementById('uploadFeedback');
    const uploadFeedbackIcon = document.getElementById('uploadFeedbackIcon');
    const uploadFeedbackTitle = document.getElementById('uploadFeedbackTitle');
    const uploadFeedbackMessage = document.getElementById('uploadFeedbackMessage');
    const dismissUploadFeedback = document.getElementById('dismissUploadFeedback');

    if (!uploadForm || !galleryGrid || !lightbox || !lightboxImg || !closeBtn || !prevBtn || !nextBtn || !uploadFeedback) return;

    let galleryImages = [];
    let currentIndex = 0;

    updateGalleryImages = function () {
        galleryImages = Array.from(document.querySelectorAll('.galeria-elem img'));
        galleryImages.forEach((img, index) => {
            img.onclick = null;
            img.addEventListener('click', () => openLightbox(index));
        });
    };

    function showImage(index) {
        if (index < 0) currentIndex = galleryImages.length - 1;
        else if (index >= galleryImages.length) currentIndex = 0;
        else currentIndex = index;
        
        lightboxImg.src = galleryImages[currentIndex].src;
        lightboxImg.alt = galleryImages[currentIndex].alt;
    }

    function openLightbox(index) {
        showImage(index);
        lightbox.classList.add('aktiv');
    }

    function closeLightbox() {
        lightbox.classList.remove('aktiv');
    }

    function addImageToGalleryUI(src) {
        const newItem = document.createElement('div');
        newItem.className = 'galeria-elem';
        newItem.innerHTML = `<img src="${src}" alt="Új fogás" loading="lazy">`;
        galleryGrid.insertBefore(newItem, galleryGrid.firstChild);
        updateGalleryImages();
    }

    function showUploadFeedback(type, title, message) {
        const icons = { figyelmeztetes: '!', hiba: '×', siker: '✓' };
        uploadFeedback.dataset.tipus = type;
        uploadFeedbackIcon.textContent = icons[type] || '!';
        uploadFeedbackTitle.textContent = title;
        uploadFeedbackMessage.textContent = message;
        uploadFeedback.hidden = false;
    }

    dismissUploadFeedback.addEventListener('click', () => {
        uploadFeedback.hidden = true;
    });

    // AI Betöltés
    try {
        aiModel = await mobilenet.load();
        uploadTitle.textContent = 'Saját fogás feltöltése';
        imageInput.disabled = false;
        uploadBtn.disabled = false;
    } catch (err) {
        uploadTitle.textContent = 'Saját fogás feltöltése (AI szűrő nélkül)';
        imageInput.disabled = false;
        uploadBtn.disabled = false;
        showUploadFeedback('figyelmeztetes', 'Az AI-ellenőrzés most nem érhető el', 'A képet ettől függetlenül feltöltheted; a szerver ellenőrzi a fájl formátumát és méretét.');
    }

    // Feltöltés AI ellenőrzéssel + Adatbázisba küldéssel
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const file = imageInput.files[0];
        if (!file) return;

        uploadFeedback.hidden = true;
        uploadBtn.disabled = true;
        try {
            if (aiModel) {
                uploadBtn.textContent = 'Kép elemzése...';
                const imageUrl = URL.createObjectURL(file);
                const img = new Image();
                img.src = imageUrl;
                await new Promise((resolve, reject) => {
                    img.onload = resolve;
                    img.onerror = () => reject(new Error('A kiválasztott kép nem olvasható.'));
                });

                let predictions;
                try {
                    predictions = await aiModel.classify(img);
                } finally {
                    URL.revokeObjectURL(imageUrl);
                }

                const keywords = [
                    'fish', 'bass', 'trout', 'salmon', 'carp', 'goldfish', 'tench', 'pike', 'perch',
                    'fishing', 'fishing rod', 'fishhook', 'lure', 'tackle', 'boat', 'lake', 'river',
                    'trophy', 'cup', 'medal', 'award', 'podium', 'altar',
                    'group', 'team', 'people', 'crowd', 'portrait', 'wedding', 'bride', 'groom', 'bridegroom', 'jersey'
                ];
                const isValid = predictions.some((prediction) => {
                    const label = prediction.className.toLowerCase();
                    return keywords.some((keyword) => label.includes(keyword));
                });

                if (!isValid) {
                    showUploadFeedback(
                        'figyelmeztetes',
                        'Ez a kép most nem illik a galériába',
                        'A galériába fogásról, kupáról vagy közös horgászélményről készült képet tölts fel. Válassz egy másik képet, és próbáld újra.'
                    );
                    return;
                }
            }

            uploadBtn.textContent = 'Feltöltés...';
            const formData = new FormData();
            formData.append('image', file);
            const response = await fetch('upload.php', {
                method: 'POST',
                body: formData
            });

            const responseText = await response.text();
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                throw new Error('A szerver nem értelmezhető választ adott. Ellenőrizd a PHP-hibanaplót.');
            }

            if (response.ok && data.status === 'success') {
                // Ha sikerült, hozzáadjuk az UI-hoz és ott is marad az adatbázis miatt!
                addImageToGalleryUI(data.imageUrl);
                showUploadFeedback('siker', 'A kép bekerült a galériába', 'Köszönjük, hogy megosztottad a horgászélményt!');
            } else {
                showUploadFeedback('hiba', 'Nem sikerült feltölteni a képet', data.message || 'Ellenőrizd a képet, majd próbáld újra.');
            }
        } catch (error) {
            showUploadFeedback('hiba', 'Nem sikerült feltölteni a képet', error.message || 'Szerverhiba történt. Próbáld újra később.');
        } finally {
            imageInput.value = '';
            uploadBtn.textContent = 'Kép hozzáadása';
            uploadBtn.disabled = false;
        }
    });

    closeBtn.addEventListener('click', closeLightbox);
    prevBtn.addEventListener('click', () => showImage(currentIndex - 1));
    nextBtn.addEventListener('click', () => showImage(currentIndex + 1));
    lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });

    updateGalleryImages();
});



// Menü nyitás / zárás funkció
function toggleMenu() {
    const overlay = document.getElementById('menuOverlay');
    overlay.classList.toggle('aktiv');
}

let locations = [];

// Térkép inicializálása
let map = null;
let locationMarkers = null;
if (document.getElementById('map') && window.L) {
    map = L.map('map').setView([47.1624, 19.5033], 7);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    locationMarkers = L.layerGroup().addTo(map);
}

let userMarker = null;

// Jelölők hozzáadása és lista generálása
function renderLocations(coords = null) {
    const listContainer = document.getElementById('locationList');
    if (!map || !locationMarkers || !listContainer) return;
    listContainer.innerHTML = '';
    locationMarkers.clearLayers();

    if (locations.length === 0) {
        const emptyMessage = document.createElement('p');
        emptyMessage.className = 'profil-ures';
        emptyMessage.textContent = 'Jelenleg nincs meghirdetett verseny.';
        listContainer.appendChild(emptyMessage);
        return;
    }

    let processedLocations = locations.map(loc => {
        let dist = null;
        if (coords) {
            dist = calculateDistance(coords.lat, coords.lng, loc.lat, loc.lng);
        }
        return { ...loc, distance: dist };
    });

    if (coords) {
        processedLocations.sort((a, b) => a.distance - b.distance);
    }

    processedLocations.forEach(loc => {
        const marker = L.marker([loc.lat, loc.lng]).addTo(locationMarkers);
        const popup = document.createElement('div');
        popup.style.color = '#000';
        const popupTitle = document.createElement('h4');
        popupTitle.style.margin = '0 0 5px';
        popupTitle.textContent = loc.name;
        const popupDate = document.createElement('div');
        popupDate.style.cssText = 'color:#2e7d32;font-weight:bold;font-size:0.85rem;margin-bottom:5px';
        popupDate.textContent = `📅 ${loc.date}`;
        const popupDescription = document.createElement('p');
        popupDescription.style.margin = '0';
        popupDescription.textContent = loc.desc;
        const bookingLink = document.createElement('a');
        bookingLink.className = 'terkep-foglalas-gomb';
        bookingLink.href = `foglalas.php?verseny_id=${encodeURIComponent(loc.id)}`;
        bookingLink.textContent = 'Foglalás';
        popup.append(popupTitle, popupDate, popupDescription, bookingLink);
        marker.bindPopup(popup);

        const card = document.createElement('div');
        card.className = 'helyszin-kartya';
        const cardTitle = document.createElement('h3');
        cardTitle.textContent = loc.name;
        const dateTag = document.createElement('div');
        dateTag.className = 'datum-cimke';
        dateTag.textContent = `📅 ${loc.date}`;
        const description = document.createElement('p');
        description.textContent = loc.desc;
        card.append(cardTitle, dateTag, description);

        if (loc.distance !== null) {
            const distance = document.createElement('div');
            distance.className = 'tavolsag-adat';
            distance.textContent = `📍 Távolság tőled: ${loc.distance.toFixed(1)} km`;
            card.appendChild(distance);
        }

        card.onclick = () => {
            map.setView([loc.lat, loc.lng], 12);
            marker.openPopup();
        };

        listContainer.appendChild(card);
    });
}

async function loadCompetitionLocations() {
    const listContainer = document.getElementById('locationList');
    if (!map || !listContainer) return;

    try {
        const response = await fetch('versenyek_api.php', { cache: 'no-store' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'A versenyhelyszíneket nem sikerült betölteni.');

        locations = data;
        renderLocations();
    } catch (error) {
        listContainer.replaceChildren();
        const errorMessage = document.createElement('p');
        errorMessage.className = 'profil-ures';
        errorMessage.textContent = error.message || 'A versenyhelyszíneket nem sikerült betölteni.';
        listContainer.appendChild(errorMessage);
        console.error('Hiba a versenyhelyszínek betöltésekor:', error);
    }
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
        Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

async function searchLocation() {
    const query = document.getElementById('cityInput').value;
    if (!query) return;

    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&countrycodes=hu`, {
            headers: {
                'User-Agent': 'HorgaszChallengeHungary/1.0'
            }
        });
        const data = await response.json();

        if (data.length > 0) {
            const lat = parseFloat(data[0].lat);
            const lon = parseFloat(data[0].lon);

            setUserPosition(lat, lon, data[0].display_name);
        } else {
            alert('A megadott település nem található!');
        }
    } catch (error) {
        console.error('Hiba a keresés során:', error);
    }
}

function getUserLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                setUserPosition(lat, lng, "Saját pozíciód");
            },
            () => {
                alert("Nem sikerült lekérni a pozíciódat.");
            }
        );
    } else {
        alert("A böngésződ nem támogatja a geolokációt.");
    }
}

function setUserPosition(lat, lng, label) {
    if (userMarker) map.removeLayer(userMarker);

    userMarker = L.circleMarker([lat, lng], {
        color: '#4caf50',
        fillColor: '#4caf50',
        fillOpacity: 0.8,
        radius: 8
    }).addTo(map);

    userMarker.bindPopup(`<b>${label}</b>`).openPopup();
    map.setView([lat, lng], 9);

    renderLocations({ lat, lng });
}

// Versenyhelyszínek betöltése az adatbázisból
loadCompetitionLocations();