<?php
function oldalbetoltes() {
    $oldal = isset($_GET["oldal"]) ? $_GET["oldal"] : "";
    
    if ($oldal=="bejelentkezes") {
        include "bejelentkezes.php";
    }
    if ($oldal=="fejlesztok") {
        include "fejlesztok.php";
    }
    if ($oldal=="foglalas") {
        include "foglalas.php";
    }
    if ($oldal=="galeria") {
        include "galeria.php";
    }    
    if ($oldal=="hirek") {
        include "hirek.php";
    }
    if ($oldal=="index") {
        include "index.php";
    }
    if ($oldal=="terkep") {
        include "terkep.php";
    }
    if ($oldal=="versenyek") {
        include "versenyek.php";
    }

}



header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    
    // 1. Alapvető hibák ellenőrzése
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Hiba történt a fájl feltöltése során."]);
        exit;
    }

    $tmpFilePath = $_FILES['image']['tmp_name'];

    // 2. KÉP DIGITÁLIS UJJLENYOMATÁNAK (HASH) KISZÁMÍTÁSA
    // Ez a kép tényleges tartalma alapján generál egy egyedi kódot.
    $imageHash = md5_file($tmpFilePath);

    // 3. ELLENŐRZÉS AZ ADATBÁZISBAN (Duplikáció szűrés)
    $checkStmt = $conn->prepare("SELECT id FROM galeria_kepek WHERE kep_hash = ?");
    $checkStmt->bind_param("s", $imageHash);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        $checkStmt->close();
        http_response_code(409); // Conflict HTTP kód
        echo json_encode([
            "status" => "error", 
            "message" => "Ez a kép már egyszer fel lett töltve a galériába!"
        ]);
        exit;
    }
    $checkStmt->close();

    // 4. MAISZTER ÉS MENTÉS
    $targetDir = "imgs/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Biztonságos és egyedi fájlnév generálása
    $fileExtension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'webp');

    if (!in_array($fileExtension, $allowTypes)) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Csak JPG, PNG, GIF és WEBP formátum engedélyezett."]);
        exit;
    }

    // Egyedi fájlnév az ujjlenyomat alapján (így a mappában sem lesz duplikált fájl!)
    $fileName = $imageHash . '.' . $fileExtension;
    $targetFilePath = $targetDir . $fileName;

    // Ha a fájl a mappában már létezik valamiért, vagy sikeres a mozgatás
    if (file_exists($targetFilePath) || move_uploaded_file($tmpFilePath, $targetFilePath)) {
        
        // Mentés az adatbázisba (Útvonal + Hash)
        $stmt = $conn->prepare("INSERT INTO galeria_kepek (kep_utvonal, kep_hash) VALUES (?, ?)");
        $stmt->bind_param("ss", $targetFilePath, $imageHash);
        
        if ($stmt->execute()) {
            echo json_encode([
                "status" => "success", 
                "imageUrl" => $targetFilePath
            ]);
            $stmt->close();
            exit;
        }
        $stmt->close();
    }
}

http_response_code(400);
echo json_encode(["status" => "error", "message" => "Hiba a mentés során."]);




header('Content-Type: application/json; charset=utf-8');

require_once 'db.php';
require_once 'verseny_adatok.php';

$versenyek = versenyekLekerdezese($pdo);
$spots = array_map(static function (array $verseny): array {
    return [
        'id' => $verseny['id'],
        'name' => $verseny['nev'],
        'lat' => $verseny['szelesseg'],
        'lon' => $verseny['hosszusag'],
        'desc' => trim($verseny['verseny_nev'] . ($verseny['leiras'] ? ' - ' . $verseny['leiras'] : '')),
        'date' => $verseny['verseny_idopont']
            ? date('Y.m.d. H:i', strtotime($verseny['verseny_idopont']))
            : 'Nincs megadva',
    ];
}, $versenyek);

echo json_encode($spots, JSON_UNESCAPED_UNICODE);
?>