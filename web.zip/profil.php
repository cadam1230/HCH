<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'], $_SESSION['email'])) {
    header('Location: bejelentkezes.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$csrfToken = $_SESSION['csrf_token'] ?? bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrfToken;
$error = '';
$success = '';

$userStmt = $pdo->prepare('SELECT id, teljes_nev, email, jelszo FROM felhasznalok WHERE id = ?');
$userStmt->execute([$userId]);
$user = $userStmt->fetch();

if (!$user) {
    session_destroy();
    header('Location: bejelentkezes.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrfToken, $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        $error = 'A kérés lejárt vagy érvénytelen. Frissítsd az oldalt, majd próbáld újra.';
    } elseif (($_POST['action'] ?? '') === 'change_password') {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!password_verify($currentPassword, $user['jelszo'])) {
            $error = 'A jelenlegi jelszó nem megfelelő.';
        } elseif (strlen($newPassword) < 8) {
            $error = 'Az új jelszó legalább 8 karakter legyen.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'Az új jelszavak nem egyeznek.';
        } elseif (password_verify($newPassword, $user['jelszo'])) {
            $error = 'Az új jelszó nem egyezhet a jelenlegivel.';
        } else {
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare('UPDATE felhasznalok SET jelszo = ? WHERE id = ?');
            $updateStmt->execute([$newHash, $userId]);
            $success = 'A jelszót sikeresen megváltoztattuk.';
        }
    } elseif (($_POST['action'] ?? '') === 'upload_profile_image') {
        $upload = $_FILES['profile_image'] ?? null;
        $maxSize = 3 * 1024 * 1024;
        $mimeExtensions = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
        ];

        if (!$upload || $upload['error'] !== UPLOAD_ERR_OK) {
            $error = 'Nem sikerült feltölteni a képet.';
        } elseif ($upload['size'] > $maxSize) {
            $error = 'A kép legfeljebb 3 MB méretű lehet.';
        } else {
            $imageInfo = getimagesize($upload['tmp_name']);
            $fileInfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $fileInfo->file($upload['tmp_name']);

            if (!$imageInfo || !isset($mimeExtensions[$mimeType]) || $imageInfo[0] > 5000 || $imageInfo[1] > 5000) {
                $error = 'Csak érvényes JPG, PNG vagy WEBP kép tölthető fel, legfeljebb 5000×5000 képpont méretben.';
            } else {
                $uploadDirectory = __DIR__ . '/imgs/profilok';
                if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
                    $error = 'Nem sikerült létrehozni a profilképek mappáját.';
                } else {
                    $extension = $mimeExtensions[$mimeType];
                    $destination = $uploadDirectory . '/' . $userId . '.' . $extension;

                    if (!move_uploaded_file($upload['tmp_name'], $destination)) {
                        $error = 'A profilkép mentése nem sikerült.';
                    } else {
                        foreach (glob($uploadDirectory . '/' . $userId . '.*') ?: [] as $oldImage) {
                            if ($oldImage !== $destination && is_file($oldImage)) {
                                unlink($oldImage);
                            }
                        }
                        $success = 'A profilképet sikeresen frissítettük.';
                    }
                }
            }
        }
    }
}

$profileImageUrl = 'imgs/profile.png';
foreach (['jpg', 'png', 'webp'] as $extension) {
    $candidate = 'imgs/profilok/' . $userId . '.' . $extension;
    if (is_file(__DIR__ . '/' . $candidate)) {
        $profileImageUrl = $candidate;
        break;
    }
}

$bookingsStmt = $pdo->prepare('SELECT datum_kezdet, datum_veg, steg FROM foglalasok WHERE email = ? ORDER BY datum_kezdet DESC');
$bookingsStmt->execute([$user['email']]);
$bookings = $bookingsStmt->fetchAll();

include 'header.php';
?>

<main class="profil-oldal">
    <div class="profil-fejlec">
        <div>
            <h1>Saját profil</h1>
            <p><?php echo htmlspecialchars($user['teljes_nev'], ENT_QUOTES, 'UTF-8'); ?> · <?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></p>
        </div>
        <a class="profil-kijelentkezes" href="bejelentkezes.php?action=logout">Kijelentkezés</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="ertesites ertesites-hiba" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>
    <?php if ($success !== ''): ?>
        <div class="ertesites ertesites-siker" role="status"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <div class="profil-racs">
        <section class="profil-szekcio">
            <h2>Profilkép</h2>
            <img class="profil-oldal-kep" src="<?php echo htmlspecialchars($profileImageUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="Jelenlegi profilkép">
            <form method="post" enctype="multipart/form-data" class="profil-urlap">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="upload_profile_image">
                <div class="urlap-mezo">
                    <label for="profile_image">Új profilkép (JPG, PNG vagy WEBP, max. 3 MB)</label>
                    <input type="file" id="profile_image" name="profile_image" accept="image/jpeg,image/png,image/webp" required>
                </div>
                <button class="kuldes-gomb" type="submit">Profilkép mentése</button>
            </form>
        </section>

        <section class="profil-szekcio">
            <h2>Jelszó módosítása</h2>
            <form method="post" class="profil-urlap">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="change_password">
                <div class="urlap-mezo">
                    <label for="current_password">Jelenlegi jelszó</label>
                    <input type="password" id="current_password" name="current_password" autocomplete="current-password" required>
                </div>
                <div class="urlap-mezo">
                    <label for="new_password">Új jelszó (legalább 8 karakter)</label>
                    <input type="password" id="new_password" name="new_password" autocomplete="new-password" minlength="8" required>
                </div>
                <div class="urlap-mezo">
                    <label for="confirm_password">Új jelszó ismét</label>
                    <input type="password" id="confirm_password" name="confirm_password" autocomplete="new-password" minlength="8" required>
                </div>
                <button class="kuldes-gomb" type="submit">Jelszó mentése</button>
            </form>
        </section>
    </div>

    <section class="profil-szekcio profil-lista-szekcio">
        <h2>Nevezéseim és foglalásaim</h2>
        <?php if ($bookings): ?>
            <div class="profil-tablazat-gorgeto">
                <table class="profil-tablazat">
                    <thead>
                        <tr><th>Helyszín</th><th>Érkezés</th><th>Távozás</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($booking['steg'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($booking['datum_kezdet'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($booking['datum_veg'], ENT_QUOTES, 'UTF-8'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="profil-ures">Még nincs rögzített nevezésed vagy foglalásod.</p>
        <?php endif; ?>
    </section>

    <section class="profil-szekcio profil-lista-szekcio">
        <h2>Helyezések</h2>
        <p class="profil-ures">A versenyeredmények rögzítése után itt jelennek meg a helyezéseid.</p>
    </section>
</main>

<?php include 'footer.php'; ?>
