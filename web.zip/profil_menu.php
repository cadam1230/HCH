<?php
$profilKepUrl = 'imgs/profile.png';
if (isset($_SESSION['user_id'])) {
    foreach (['jpg', 'png', 'webp'] as $kiterjesztes) {
        $jeloltKep = 'imgs/profilok/' . (int)$_SESSION['user_id'] . '.' . $kiterjesztes;
        if (is_file($jeloltKep)) {
            $profilKepUrl = $jeloltKep;
            break;
        }
    }
}
$profilLink = isset($_SESSION['user_id']) ? 'profil.php' : 'bejelentkezes.php';
?>
<div class="bejelentkezes">
    <a href="<?php echo $profilLink; ?>">
        <img src="<?php echo htmlspecialchars($profilKepUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="profil-kep">
        <span class="profil-nev"><?php echo htmlspecialchars($_SESSION['teljes_nev'] ?? 'Profil', ENT_QUOTES, 'UTF-8'); ?></span>
    </a>
</div>
