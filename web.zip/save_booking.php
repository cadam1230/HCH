<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function readBookingInput(): array
{
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        respond(400, ['status' => 'error', 'message' => 'Érvénytelen kérésadat.']);
    }

    $booking = [
        'nev' => trim($input['nev'] ?? ''),
        'email' => trim($input['email'] ?? ''),
        'datum_kezdet' => trim($input['datum_kezdet'] ?? ''),
        'datum_veg' => trim($input['datum_veg'] ?? ''),
        'steg' => trim($input['steg'] ?? ''),
    ];

    if (in_array('', $booking, true) || !filter_var($booking['email'], FILTER_VALIDATE_EMAIL)) {
        respond(400, ['status' => 'error', 'message' => 'Adj meg minden adatot érvényes e-mail címmel.']);
    }

    foreach (['datum_kezdet', 'datum_veg'] as $field) {
        $date = DateTime::createFromFormat('!Y-m-d', $booking[$field]);
        if (!$date || $date->format('Y-m-d') !== $booking[$field]) {
            respond(400, ['status' => 'error', 'message' => 'Érvénytelen dátum.']);
        }
    }

    if ($booking['datum_kezdet'] > $booking['datum_veg']) {
        respond(400, ['status' => 'error', 'message' => 'A távozási dátum nem lehet korábbi az érkezésnél.']);
    }

    return $booking;
}

function hasOverlap(mysqli $conn, string $steg, string $start, string $end, ?int $excludeId = null): bool
{
    if ($excludeId === null) {
        $stmt = $conn->prepare('SELECT id FROM foglalasok WHERE steg = ? AND NOT (datum_veg < ? OR datum_kezdet > ?) LIMIT 1');
        $stmt->bind_param('sss', $steg, $start, $end);
    } else {
        $stmt = $conn->prepare('SELECT id FROM foglalasok WHERE steg = ? AND id <> ? AND NOT (datum_veg < ? OR datum_kezdet > ?) LIMIT 1');
        $stmt->bind_param('siss', $steg, $excludeId, $start, $end);
    }

    $stmt->execute();
    $overlap = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $overlap;
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if (isset($_GET['mine'])) {
        if (!isset($_SESSION['user_id'], $_SESSION['email'])) {
            respond(401, ['status' => 'error', 'message' => 'A foglalások szerkesztéséhez jelentkezz be.']);
        }

        $stmt = $conn->prepare('SELECT id, nev, email, datum_kezdet, datum_veg, steg FROM foglalasok WHERE email = ? ORDER BY datum_kezdet');
        $stmt->bind_param('s', $_SESSION['email']);
        $stmt->execute();
        $result = $stmt->get_result();
        $bookings = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        echo json_encode($bookings, JSON_UNESCAPED_UNICODE);
        exit;
    }

    $result = $conn->query('SELECT id, steg, datum_kezdet, datum_veg FROM foglalasok');
    if (!$result) {
        respond(500, ['status' => 'error', 'message' => 'A foglaltság lekérése nem sikerült.']);
    }

    echo json_encode($result->fetch_all(MYSQLI_ASSOC), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'POST') {
    $booking = readBookingInput();
    if (isset($_SESSION['user_id']) && strcasecmp($booking['email'], $_SESSION['email']) !== 0) {
        respond(403, ['status' => 'error', 'message' => 'Bejelentkezve csak a saját e-mail címeddel foglalhatsz.']);
    }

    if (hasOverlap($conn, $booking['steg'], $booking['datum_kezdet'], $booking['datum_veg'])) {
        respond(409, ['status' => 'error', 'message' => 'A kiválasztott időszak már foglalt ezen a helyen.']);
    }

    $stmt = $conn->prepare('INSERT INTO foglalasok (nev, email, datum_kezdet, datum_veg, steg) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('sssss', $booking['nev'], $booking['email'], $booking['datum_kezdet'], $booking['datum_veg'], $booking['steg']);
    if (!$stmt->execute()) {
        $stmt->close();
        respond(500, ['status' => 'error', 'message' => 'A foglalás mentése nem sikerült.']);
    }

    $stmt->close();
    respond(201, ['status' => 'success', 'message' => 'Foglalás sikeresen rögzítve!', 'id' => $conn->insert_id]);
}

if ($method === 'PUT') {
    if (!isset($_SESSION['user_id'], $_SESSION['email'])) {
        respond(401, ['status' => 'error', 'message' => 'A foglalás módosításához jelentkezz be.']);
    }

    $input = json_decode(file_get_contents('php://input'), true);
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) {
        respond(400, ['status' => 'error', 'message' => 'Érvénytelen foglalásazonosító.']);
    }

    $booking = readBookingInput();
    if (strcasecmp($booking['email'], $_SESSION['email']) !== 0) {
        respond(403, ['status' => 'error', 'message' => 'Csak a saját foglalásodat módosíthatod.']);
    }

    $ownerStmt = $conn->prepare('SELECT id FROM foglalasok WHERE id = ? AND email = ?');
    $ownerStmt->bind_param('is', $id, $_SESSION['email']);
    $ownerStmt->execute();
    $isOwner = $ownerStmt->get_result()->num_rows === 1;
    $ownerStmt->close();
    if (!$isOwner) {
        respond(404, ['status' => 'error', 'message' => 'A foglalás nem található a saját foglalásaid között.']);
    }

    if (hasOverlap($conn, $booking['steg'], $booking['datum_kezdet'], $booking['datum_veg'], $id)) {
        respond(409, ['status' => 'error', 'message' => 'A kiválasztott időszak már foglalt ezen a helyen.']);
    }

    $stmt = $conn->prepare('UPDATE foglalasok SET nev = ?, datum_kezdet = ?, datum_veg = ?, steg = ? WHERE id = ? AND email = ?');
    $stmt->bind_param('ssssis', $booking['nev'], $booking['datum_kezdet'], $booking['datum_veg'], $booking['steg'], $id, $_SESSION['email']);
    if (!$stmt->execute()) {
        $stmt->close();
        respond(500, ['status' => 'error', 'message' => 'A foglalás módosítása nem sikerült.']);
    }

    $stmt->close();
    respond(200, ['status' => 'success', 'message' => 'Foglalás sikeresen módosítva!']);
}

if ($method === 'DELETE') {
    if (!isset($_SESSION['user_id'], $_SESSION['email'])) {
        respond(401, ['status' => 'error', 'message' => 'A foglalás visszamondásához jelentkezz be.']);
    }

    $input = json_decode(file_get_contents('php://input'), true);
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) {
        respond(400, ['status' => 'error', 'message' => 'Érvénytelen foglalásazonosító.']);
    }

    $stmt = $conn->prepare('DELETE FROM foglalasok WHERE id = ? AND email = ?');
    $stmt->bind_param('is', $id, $_SESSION['email']);
    if (!$stmt->execute()) {
        $stmt->close();
        respond(500, ['status' => 'error', 'message' => 'A foglalás törlése nem sikerült.']);
    }

    $deleted = $stmt->affected_rows === 1;
    $stmt->close();
    if (!$deleted) {
        respond(404, ['status' => 'error', 'message' => 'A foglalás nem található a saját foglalásaid között.']);
    }

    respond(200, ['status' => 'success', 'message' => 'A foglalást sikeresen visszamondtuk.']);
}

header('Allow: GET, POST, PUT, DELETE');
respond(405, ['status' => 'error', 'message' => 'Nem engedélyezett kérés.']);
