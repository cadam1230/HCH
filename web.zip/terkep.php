<?php if (session_status() !== PHP_SESSION_ACTIVE) session_start(); ?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interaktív Térkép - Horgász Challenge Hungary</title>
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="stilusok.css?v=<?php echo filemtime(__DIR__ . '/stilusok.css'); ?>">
</head>
<body class="terkep-oldal">

    <header>
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Horgász Challenge Hungary Logo" class="logo-kep">
            </a>
        </div>
        <?php include 'profil_menu.php'; ?>
        <div class="fejlec-gombok">
            <?php include 'admin_menu.php'; ?>
            <button class="menu-gomb" onclick="toggleMenu()">Menü ☰</button>
        </div>
    </header>

    <!-- Felugró Menü -->
    <div class="menu-reteg" id="menuOverlay">
        <button class="close-btn" onclick="toggleMenu()">✕</button>
        <nav class="menu-tartalom">
            <ul>
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="foglalas.php">Foglalás</a></li>
                <li><a href="versenyek.php">Versenyek</a></li>
                <li><a href="galeria.php">Galéria</a></li>
                <li><a href="terkep.php">Térkép</a></li>
                <li><a href="hirek.php">Hírek</a></li>
                <li><a href="fejlesztok.php">Weboldal fejlesztői</a></li>
            </ul>
        </nav>
    </div>

    <div class="fo-kontener">
        <div class="oldalsav">
            <div class="kereso-doboz">
                <input type="text" id="cityInput" placeholder="Írd be a településed..." onkeypress="if(event.key === 'Enter') searchLocation()">
                <button onclick="searchLocation()">Keresés a térképen</button>
                <button onclick="getUserLocation()" style="margin-top: 8px; background-color: transparent; color: var(--szoveg-vilagos); border: 1px solid var(--keret-szin);">Saját pozíció használata</button>
            </div>
            <div class="helyszin-lista" id="locationList">
                <!-- A kártyák dinamikusan kerülnek ide -->
            </div>
        </div>
        <div id="map"></div>
    </div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="js.js?v=<?php echo filemtime(__DIR__ . '/js.js'); ?>"></script>
</body>
</html>