<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

function uploadResponse(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    uploadResponse(405, ['status' => 'error', 'message' => 'Nem engedélyezett kérés.']);
}

if (!isset($_FILES['image'])) {
    uploadResponse(400, ['status' => 'error', 'message' => 'Nem érkezett feltöltendő kép.']);
}

$image = $_FILES['image'];
if ($image['error'] !== UPLOAD_ERR_OK) {
    uploadResponse(400, ['status' => 'error', 'message' => 'A kép feltöltése nem sikerült.']);
}

$maxFileSize = 8 * 1024 * 1024;
if ($image['size'] < 1 || $image['size'] > $maxFileSize) {
    uploadResponse(413, ['status' => 'error', 'message' => 'A kép mérete legfeljebb 8 MB lehet.']);
}

$fileInfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $fileInfo->file($image['tmp_name']);
$allowedTypes = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/gif' => 'gif',
    'image/webp' => 'webp',
];
$imageInfo = getimagesize($image['tmp_name']);

if (!$imageInfo || !isset($allowedTypes[$mimeType]) || $imageInfo[0] > 6000 || $imageInfo[1] > 6000) {
    uploadResponse(400, ['status' => 'error', 'message' => 'Csak érvényes JPG, PNG, GIF vagy WEBP kép tölthető fel, legfeljebb 6000×6000 képpont méretben.']);
}

$imageHash = md5_file($image['tmp_name']);
$duplicateStmt = $conn->prepare('SELECT id FROM galeria_kepek WHERE kep_hash = ?');
$duplicateStmt->bind_param('s', $imageHash);
$duplicateStmt->execute();
$isDuplicate = $duplicateStmt->get_result()->num_rows > 0;
$duplicateStmt->close();

if ($isDuplicate) {
    uploadResponse(409, ['status' => 'error', 'message' => 'Ez a kép már szerepel a galériában.']);
}

$targetDirectory = __DIR__ . '/imgs';
if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0755, true) && !is_dir($targetDirectory)) {
    uploadResponse(500, ['status' => 'error', 'message' => 'A képmappa nem hozható létre.']);
}

$fileName = $imageHash . '.' . $allowedTypes[$mimeType];
$relativePath = 'imgs/' . $fileName;
$targetPath = $targetDirectory . '/' . $fileName;

if (!move_uploaded_file($image['tmp_name'], $targetPath)) {
    uploadResponse(500, ['status' => 'error', 'message' => 'A kép fájlba mentése nem sikerült.']);
}

$insertStmt = $conn->prepare('INSERT INTO galeria_kepek (kep_utvonal, kep_hash) VALUES (?, ?)');
$insertStmt->bind_param('ss', $relativePath, $imageHash);
if (!$insertStmt->execute()) {
    $insertStmt->close();
    if (is_file($targetPath)) unlink($targetPath);
    uploadResponse(500, ['status' => 'error', 'message' => 'A kép adatbázisba mentése nem sikerült.']);
}
$insertStmt->close();

uploadResponse(201, ['status' => 'success', 'imageUrl' => $relativePath]);
