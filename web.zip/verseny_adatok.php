<?php
function versenyekLekerdezese(PDO $pdo): array
{
    $stmt = $pdo->query(
        'SELECT v.id, v.helyszin_id, v.nev AS verseny_nev, v.leiras, v.idopont AS verseny_idopont,
                f.nev, f.szelesseg, f.hosszusag
         FROM versenyek v
         INNER JOIN fishing_spots f ON f.id = v.helyszin_id
         ORDER BY v.idopont IS NULL, v.idopont, f.nev, v.nev'
    );

    $versenyek = $stmt->fetchAll();
    foreach ($versenyek as &$verseny) {
        $verseny['id'] = (int)$verseny['id'];
        $verseny['helyszin_id'] = (int)$verseny['helyszin_id'];
        $verseny['szelesseg'] = (float)$verseny['szelesseg'];
        $verseny['hosszusag'] = (float)$verseny['hosszusag'];
    }
    unset($verseny);

    return $versenyek;
}
