<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once 'db.php';
require_once 'verseny_adatok.php';
$versenyek = versenyekLekerdezese($pdo);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Versenyek - Horgász Challenge Hungary</title>
    <link rel="stylesheet" href="stilusok.css?v=<?php echo filemtime(__DIR__ . '/stilusok.css'); ?>">
</head>
<body>

    <header>
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Horgász Challenge Hungary Logo" class="logo-kep">
            </a>
        </div>
        <?php include 'profil_menu.php'; ?>
        <div class="fejlec-gombok">
            <?php include 'admin_menu.php'; ?>
            <button class="menu-gomb" onclick="toggleMenu()">Menü ☰</button>
        </div>
    </header>

    <div class="menu-reteg" id="menuOverlay">
        <button class="close-btn" onclick="toggleMenu()">✕</button>
        <nav class="menu-tartalom">
            <ul>
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="foglalas.php">Foglalás</a></li>
                <li><a href="versenyek.php">Versenyek</a></li>
                <li><a href="galeria.php">Galéria</a></li>
                <li><a href="terkep.php">Térkép</a></li>
                <li><a href="hirek.php">Hírek</a></li>
                <li><a href="fejlesztok.php">Weboldal fejlesztői</a></li>
            </ul>
        </nav>
    </div>

    <main>
        <h1>Aktív Horgászversenyek</h1>
        <p class="alcim">Tekintsd meg a legújabb és legizgalmasabb versenyeinket!</p>

        <div class="verseny-lista">
            <?php if ($versenyek): ?>
                <?php foreach ($versenyek as $verseny): ?>
                    <a class="verseny-kartya" href="foglalas.php?verseny_id=<?php echo (int)$verseny['id']; ?>" aria-label="Foglalás: <?php echo htmlspecialchars($verseny['nev'], ENT_QUOTES, 'UTF-8'); ?>">
                        <h2><?php echo htmlspecialchars($verseny['nev'], ENT_QUOTES, 'UTF-8'); ?></h2>
                        <p><strong>Esemény:</strong> <?php echo htmlspecialchars($verseny['verseny_nev'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <?php if (!empty($verseny['leiras'])): ?>
                            <p><?php echo htmlspecialchars($verseny['leiras'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <?php endif; ?>
                        <p><strong>Időpont:</strong>
                            <?php echo $verseny['verseny_idopont']
                                ? htmlspecialchars(date('Y. m. d. H:i', strtotime($verseny['verseny_idopont'])), ENT_QUOTES, 'UTF-8')
                                : 'Nincs megadva'; ?>
                        </p>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="verseny-ures">Jelenleg nincs meghirdetett verseny.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>© 2026 Horgász Challenge Hungary - Minden jog fenntartva.</p>
    </footer>

    <script src="js.js"></script>
</body>
</html>