<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';
require_once 'verseny_adatok.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    echo json_encode(['error' => 'Nem engedélyezett kérés.'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $versenyek = versenyekLekerdezese($pdo);
    $terkepAdatok = array_map(static function (array $verseny): array {
        $datum = $verseny['verseny_idopont'];
        return [
            'id' => (int)$verseny['id'],
            'name' => $verseny['nev'],
            'lat' => $verseny['szelesseg'],
            'lng' => $verseny['hosszusag'],
            'date' => $datum ? date('Y.m.d. H:i', strtotime($datum)) : 'Nincs megadva',
            'desc' => trim($verseny['verseny_nev'] . ($verseny['leiras'] ? ' - ' . $verseny['leiras'] : '')),
        ];
    }, $versenyek);

    echo json_encode($terkepAdatok, JSON_UNESCAPED_UNICODE);
} catch (Throwable $error) {
    error_log($error->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'A versenyadatokat nem sikerült betölteni.'], JSON_UNESCAPED_UNICODE);
}
